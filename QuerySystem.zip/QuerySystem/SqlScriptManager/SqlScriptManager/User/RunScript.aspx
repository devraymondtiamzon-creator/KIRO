<%@ Page Title="Run Scripts" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" 
    CodeBehind="RunScript.aspx.cs" Inherits="SqlScriptManager.User.RunScript" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">

    <div class="page-header">
        <h2>Run Scripts</h2>
    </div>

    <!-- Credentials Section -->
    <div class="credentials-section">
        <h4>Database Credentials (optional - leave blank for Windows Authentication)</h4>
        <div class="form-group">
            <label for="<%= txtUsername.ClientID %>">Username</label>
            <asp:TextBox ID="txtUsername" runat="server" CssClass="form-control" 
                placeholder="SQL Server username" AutoCompleteType="None" />
        </div>
        <div class="form-group">
            <label for="<%= txtPassword.ClientID %>">Password</label>
            <asp:TextBox ID="txtPassword" runat="server" CssClass="form-control" TextMode="Password" 
                placeholder="SQL Server password" />
        </div>
    </div>

    <!-- Script Selection -->
    <div class="panel">
        <div class="panel-header">Select a Script to Run</div>

        <!-- Search / Filter -->
        <div class="search-bar">
            <asp:TextBox ID="txtSearch" runat="server" CssClass="form-control" 
                placeholder="Search scripts by name, description, or database..." />
            <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="btn btn-primary" 
                OnClick="btnSearch_Click" />
            <asp:Button ID="btnClearSearch" runat="server" Text="Clear" CssClass="btn btn-secondary" 
                OnClick="btnClearSearch_Click" />
        </div>

        <!-- Scripts Grid for Selection -->
        <div class="grid-container">
            <asp:GridView ID="gvScripts" runat="server" AutoGenerateColumns="false" 
                CssClass="data-grid" GridLines="None" 
                EmptyDataText="No scripts available."
                OnRowCommand="gvScripts_RowCommand"
                DataKeyNames="ScriptID">
                <Columns>
                    <asp:TemplateField HeaderText="Action" ItemStyle-CssClass="action-cell">
                        <ItemTemplate>
                            <asp:LinkButton ID="lnkSelect" runat="server" CommandName="SelectScript" 
                                CommandArgument='<%# Eval("ScriptID") %>' CssClass="btn btn-sm btn-primary"
                                Text="Select" />
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="ScriptName" HeaderText="Script Name" />
                    <asp:BoundField DataField="Description" HeaderText="Description" />
                    <asp:BoundField DataField="DatabaseName" HeaderText="Database" />
                    <asp:BoundField DataField="CreatedBy" HeaderText="Created By" />
                    <asp:BoundField DataField="DateCreated" HeaderText="Date Created" DataFormatString="{0:yyyy-MM-dd}" />
                </Columns>
            </asp:GridView>
        </div>
    </div>

    <!-- Selected Script Details & Execution -->
    <asp:Panel ID="pnlSelectedScript" runat="server" Visible="false" CssClass="panel">
        <div class="panel-header">
            Selected Script: <asp:Label ID="lblSelectedScriptName" runat="server" CssClass="text-muted" />
        </div>

        <asp:HiddenField ID="hdnSelectedScriptID" runat="server" />
        <asp:HiddenField ID="hdnSelectedDatabaseID" runat="server" />

        <div class="form-group">
            <label>Database:</label>
            <asp:Label ID="lblSelectedDatabase" runat="server" style="font-weight: normal;" />
        </div>

        <div class="form-group">
            <label>Script:</label>
            <asp:TextBox ID="txtSelectedScript" runat="server" CssClass="form-control" 
                TextMode="MultiLine" Rows="8" ReadOnly="true" 
                style="background-color: #f8f9fa; font-family: Consolas, monospace;" />
        </div>

        <!-- Parameter Input Panel -->
        <asp:Panel ID="pnlParameters" runat="server" Visible="false">
            <div class="param-dialog">
                <h4 style="margin: 0 0 12px 0; color: #2c3e50;">Enter Parameter Values</h4>
                <asp:Repeater ID="rptParameters" runat="server">
                    <ItemTemplate>
                        <div class="form-group">
                            <label><%# Container.DataItem.ToString() %></label>
                            <asp:TextBox ID="txtParamValue" runat="server" CssClass="form-control" 
                                placeholder='<%# "Enter value for " + Container.DataItem.ToString() %>' 
                                style="max-width: 400px;" />
                            <asp:HiddenField ID="hdnParamName" runat="server" Value='<%# Container.DataItem.ToString() %>' />
                        </div>
                    </ItemTemplate>
                </asp:Repeater>
            </div>
        </asp:Panel>

        <div style="margin-top: 16px; display: flex; gap: 10px;">
            <asp:Button ID="btnRun" runat="server" Text="Run Script" CssClass="btn btn-success" 
                OnClick="btnRun_Click" />
            <asp:Button ID="btnClearSelection" runat="server" Text="Clear Selection" CssClass="btn btn-secondary" 
                OnClick="btnClearSelection_Click" />
        </div>
    </asp:Panel>

    <!-- Status Message -->
    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <!-- Results Panel -->
    <asp:Panel ID="pnlResults" runat="server" Visible="false" CssClass="panel">
        <div class="panel-header">
            Execution Results
            <asp:Label ID="lblRowCount" runat="server" CssClass="text-muted" style="font-size: 13px; margin-left: 10px;" />
        </div>
        <div class="results-container">
            <asp:GridView ID="gvResults" runat="server" AutoGenerateColumns="true" 
                CssClass="data-grid" GridLines="None" 
                EmptyDataText="Query returned no results." />
        </div>
    </asp:Panel>

</asp:Content>
