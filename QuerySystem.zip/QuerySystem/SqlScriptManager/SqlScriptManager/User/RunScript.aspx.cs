using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using SqlScriptManager.DAL;

namespace SqlScriptManager.User
{
    public partial class RunScript : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindScriptsGrid();
            }
        }

        /// <summary>
        /// Binds the scripts selection grid with optional search filtering.
        /// </summary>
        private void BindScriptsGrid(string searchTerm = null)
        {
            try
            {
                var dt = ScriptRepository.GetAllScripts(searchTerm);
                gvScripts.DataSource = dt;
                gvScripts.DataBind();
            }
            catch (Exception ex)
            {
                ShowMessage("Error loading scripts: " + ex.Message, "message message-error");
            }
        }

        /// <summary>
        /// Handles search button click.
        /// </summary>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindScriptsGrid(txtSearch.Text.Trim());
        }

        /// <summary>
        /// Clears search and reloads all scripts.
        /// </summary>
        protected void btnClearSearch_Click(object sender, EventArgs e)
        {
            txtSearch.Text = string.Empty;
            BindScriptsGrid();
        }

        /// <summary>
        /// Handles row commands from the scripts grid (Select).
        /// </summary>
        protected void gvScripts_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "SelectScript")
            {
                int scriptId = Convert.ToInt32(e.CommandArgument);
                LoadSelectedScript(scriptId);
            }
        }

        /// <summary>
        /// Loads the selected script details and shows the execution panel.
        /// </summary>
        private void LoadSelectedScript(int scriptId)
        {
            try
            {
                var script = ScriptRepository.GetScriptByID(scriptId);
                if (script == null)
                {
                    ShowMessage("Script not found.", "message message-error");
                    return;
                }

                // Populate the selected script panel
                hdnSelectedScriptID.Value = script.ScriptID.ToString();
                hdnSelectedDatabaseID.Value = script.DatabaseID.ToString();
                lblSelectedScriptName.Text = script.ScriptName;
                lblSelectedDatabase.Text = script.DatabaseName;
                txtSelectedScript.Text = script.ScriptText;

                // Check for parameters
                var parameters = ScriptRepository.ExtractParameters(script.ScriptText);
                if (parameters.Count > 0)
                {
                    rptParameters.DataSource = parameters;
                    rptParameters.DataBind();
                    pnlParameters.Visible = true;
                }
                else
                {
                    pnlParameters.Visible = false;
                }

                pnlSelectedScript.Visible = true;
                pnlResults.Visible = false;
                pnlMessage.Visible = false;
            }
            catch (Exception ex)
            {
                ShowMessage("Error loading script: " + ex.Message, "message message-error");
            }
        }

        /// <summary>
        /// Executes the selected script with provided parameters and credentials.
        /// </summary>
        protected void btnRun_Click(object sender, EventArgs e)
        {
            try
            {
                int scriptId = Convert.ToInt32(hdnSelectedScriptID.Value);
                int databaseId = Convert.ToInt32(hdnSelectedDatabaseID.Value);
                string scriptText = txtSelectedScript.Text;
                string currentUser = GetCurrentUser();

                // Build credentials from user input
                var credentials = new UserCredentials
                {
                    Username = txtUsername.Text.Trim(),
                    Password = txtPassword.Text
                };

                // Collect parameter values
                var paramValues = new Dictionary<string, string>();
                foreach (RepeaterItem item in rptParameters.Items)
                {
                    var hdnParamName = (HiddenField)item.FindControl("hdnParamName");
                    var txtParamValue = (TextBox)item.FindControl("txtParamValue");

                    if (hdnParamName != null && txtParamValue != null)
                    {
                        paramValues[hdnParamName.Value] = txtParamValue.Text.Trim();
                    }
                }

                // Execute the script
                var results = ScriptRepository.ExecuteScript(
                    scriptId, databaseId, scriptText, paramValues, credentials, currentUser);

                // Display results
                gvResults.DataSource = results;
                gvResults.DataBind();

                pnlResults.Visible = true;
                lblRowCount.Text = string.Format("({0} row{1} returned)",
                    results.Rows.Count, results.Rows.Count == 1 ? "" : "s");

                ShowMessage("Script executed successfully.", "message message-success");
            }
            catch (Exception ex)
            {
                pnlResults.Visible = false;
                ShowMessage("Execution error: " + ex.Message, "message message-error");
            }
        }

        /// <summary>
        /// Clears the selected script and hides execution panels.
        /// </summary>
        protected void btnClearSelection_Click(object sender, EventArgs e)
        {
            pnlSelectedScript.Visible = false;
            pnlResults.Visible = false;
            pnlMessage.Visible = false;
            hdnSelectedScriptID.Value = "0";
            hdnSelectedDatabaseID.Value = "0";
        }

        /// <summary>
        /// Shows a status message.
        /// </summary>
        private void ShowMessage(string text, string cssClass)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = cssClass;
            lblMessage.Text = text;
        }

        /// <summary>
        /// Gets the current user identity.
        /// </summary>
        private string GetCurrentUser()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
                return User.Identity.Name;

            // Fall back to the credentials username if provided
            if (!string.IsNullOrWhiteSpace(txtUsername.Text))
                return txtUsername.Text.Trim();

            return Environment.UserName;
        }
    }
}
