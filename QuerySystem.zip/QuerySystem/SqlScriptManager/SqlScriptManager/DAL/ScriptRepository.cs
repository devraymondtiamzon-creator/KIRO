using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace SqlScriptManager.DAL
{
    /// <summary>
    /// Repository class for script and database CRUD operations.
    /// </summary>
    public static class ScriptRepository
    {
        #region Script Operations

        /// <summary>
        /// Gets all active scripts, optionally filtered by search term.
        /// </summary>
        public static DataTable GetAllScripts(string searchTerm = null)
        {
            var param = new SqlParameter("@SearchTerm", SqlDbType.NVarChar, 200);
            param.Value = string.IsNullOrWhiteSpace(searchTerm) ? (object)DBNull.Value : searchTerm.Trim();

            return DatabaseHelper.ExecuteStoredProcedure("usp_GetAllScripts", param);
        }

        /// <summary>
        /// Gets a single script by its ID.
        /// </summary>
        public static ScriptModel GetScriptByID(int scriptId)
        {
            var param = new SqlParameter("@ScriptID", SqlDbType.Int) { Value = scriptId };
            var dt = DatabaseHelper.ExecuteStoredProcedure("usp_GetScriptByID", param);

            if (dt.Rows.Count == 0)
                return null;

            var row = dt.Rows[0];
            return new ScriptModel
            {
                ScriptID = Convert.ToInt32(row["ScriptID"]),
                ScriptName = row["ScriptName"].ToString(),
                Description = row["Description"] == DBNull.Value ? string.Empty : row["Description"].ToString(),
                DatabaseID = Convert.ToInt32(row["DatabaseID"]),
                DatabaseName = row["DatabaseName"].ToString(),
                ScriptText = row["ScriptText"].ToString(),
                CreatedBy = row["CreatedBy"].ToString(),
                DateCreated = Convert.ToDateTime(row["DateCreated"]),
                UpdatedBy = row["UpdatedBy"] == DBNull.Value ? string.Empty : row["UpdatedBy"].ToString(),
                DateUpdated = row["DateUpdated"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(row["DateUpdated"])
            };
        }

        /// <summary>
        /// Inserts a new script and returns the new ScriptID.
        /// </summary>
        public static int InsertScript(string scriptName, string description, int databaseId, string scriptText, string createdBy)
        {
            var parameters = new[]
            {
                new SqlParameter("@ScriptName", SqlDbType.NVarChar, 200) { Value = scriptName },
                new SqlParameter("@Description", SqlDbType.NVarChar, 1000) { Value = (object)description ?? DBNull.Value },
                new SqlParameter("@DatabaseID", SqlDbType.Int) { Value = databaseId },
                new SqlParameter("@ScriptText", SqlDbType.NVarChar, -1) { Value = scriptText },
                new SqlParameter("@CreatedBy", SqlDbType.NVarChar, 100) { Value = createdBy }
            };

            var result = DatabaseHelper.ExecuteScalar("usp_InsertScript", parameters);
            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Updates an existing script.
        /// </summary>
        public static void UpdateScript(int scriptId, string scriptName, string description, int databaseId, string scriptText, string updatedBy)
        {
            var parameters = new[]
            {
                new SqlParameter("@ScriptID", SqlDbType.Int) { Value = scriptId },
                new SqlParameter("@ScriptName", SqlDbType.NVarChar, 200) { Value = scriptName },
                new SqlParameter("@Description", SqlDbType.NVarChar, 1000) { Value = (object)description ?? DBNull.Value },
                new SqlParameter("@DatabaseID", SqlDbType.Int) { Value = databaseId },
                new SqlParameter("@ScriptText", SqlDbType.NVarChar, -1) { Value = scriptText },
                new SqlParameter("@UpdatedBy", SqlDbType.NVarChar, 100) { Value = updatedBy }
            };

            DatabaseHelper.ExecuteNonQuery("usp_UpdateScript", parameters);
        }

        /// <summary>
        /// Soft-deletes a script.
        /// </summary>
        public static void DeleteScript(int scriptId, string updatedBy)
        {
            var parameters = new[]
            {
                new SqlParameter("@ScriptID", SqlDbType.Int) { Value = scriptId },
                new SqlParameter("@UpdatedBy", SqlDbType.NVarChar, 100) { Value = updatedBy }
            };

            DatabaseHelper.ExecuteNonQuery("usp_DeleteScript", parameters);
        }

        #endregion

        #region Database Operations

        /// <summary>
        /// Gets all active target databases (for combo box binding).
        /// </summary>
        public static DataTable GetActiveDatabases()
        {
            return DatabaseHelper.ExecuteStoredProcedure("usp_GetActiveDatabases");
        }

        /// <summary>
        /// Gets the connection string for a specific database ID.
        /// </summary>
        public static DatabaseModel GetDatabaseConnection(int databaseId)
        {
            var param = new SqlParameter("@DatabaseID", SqlDbType.Int) { Value = databaseId };
            var dt = DatabaseHelper.ExecuteStoredProcedure("usp_GetConnectionString", param);

            if (dt.Rows.Count == 0)
                return null;

            var row = dt.Rows[0];
            return new DatabaseModel
            {
                DatabaseID = databaseId,
                ConnectionString = row["ConnectionString"].ToString(),
                ServerName = row["ServerName"].ToString(),
                DatabaseName = row["DatabaseName"].ToString()
            };
        }

        #endregion

        #region Script Execution

        /// <summary>
        /// Extracts parameter placeholders from a script.
        /// Parameters are defined as &amp;parameterName in WHERE clauses.
        /// </summary>
        public static List<string> ExtractParameters(string scriptText)
        {
            var parameters = new List<string>();
            if (string.IsNullOrWhiteSpace(scriptText))
                return parameters;

            // Match &parameter pattern (e.g., field = &parameterName)
            var regex = new Regex(@"&(\w+)", RegexOptions.IgnoreCase);
            var matches = regex.Matches(scriptText);

            foreach (Match match in matches)
            {
                string paramName = match.Groups[1].Value;
                if (!parameters.Contains(paramName))
                {
                    parameters.Add(paramName);
                }
            }

            return parameters;
        }

        /// <summary>
        /// Replaces parameter placeholders in the script with actual values.
        /// Uses parameterized queries to prevent SQL injection.
        /// </summary>
        public static string BuildExecutableQuery(string scriptText, Dictionary<string, string> parameterValues)
        {
            if (parameterValues == null || parameterValues.Count == 0)
                return scriptText;

            string result = scriptText;
            foreach (var kvp in parameterValues)
            {
                // Replace &paramName with the properly quoted value
                // Use single quotes for string values, handle numeric detection
                string value = kvp.Value;
                string replacement;

                // Check if value is numeric
                decimal numericValue;
                if (decimal.TryParse(value, out numericValue))
                {
                    replacement = value;
                }
                else
                {
                    // Escape single quotes in string values to prevent SQL injection
                    replacement = "'" + value.Replace("'", "''") + "'";
                }

                result = Regex.Replace(result, @"&" + Regex.Escape(kvp.Key), replacement, RegexOptions.IgnoreCase);
            }

            return result;
        }

        /// <summary>
        /// Executes a script on the target database and returns results.
        /// </summary>
        public static DataTable ExecuteScript(int scriptId, int databaseId, string scriptText,
            Dictionary<string, string> parameterValues, UserCredentials credentials, string executedBy)
        {
            // Build the executable query with parameters replaced
            string executableQuery = BuildExecutableQuery(scriptText, parameterValues);

            // Get the target database connection info
            var dbInfo = GetDatabaseConnection(databaseId);
            if (dbInfo == null)
                throw new Exception("Database configuration not found.");

            DataTable result = null;
            bool success = true;
            string errorMessage = null;
            int? rowsReturned = null;

            try
            {
                result = DatabaseHelper.ExecuteQueryOnTarget(dbInfo.ConnectionString, executableQuery, credentials);
                rowsReturned = result.Rows.Count;
            }
            catch (Exception ex)
            {
                success = false;
                errorMessage = ex.Message;
                throw;
            }
            finally
            {
                // Log the execution
                string parametersJson = null;
                if (parameterValues != null && parameterValues.Count > 0)
                {
                    parametersJson = Newtonsoft.Json.JsonConvert.SerializeObject(parameterValues);
                }

                try
                {
                    LogExecution(scriptId, databaseId, executedBy, parametersJson, success, errorMessage, rowsReturned);
                }
                catch
                {
                    // Don't let logging failures prevent the main operation
                }
            }

            return result;
        }

        /// <summary>
        /// Logs a script execution to the audit table.
        /// </summary>
        private static void LogExecution(int scriptId, int databaseId, string executedBy,
            string parametersUsed, bool success, string errorMessage, int? rowsReturned)
        {
            var parameters = new[]
            {
                new SqlParameter("@ScriptID", SqlDbType.Int) { Value = scriptId },
                new SqlParameter("@DatabaseID", SqlDbType.Int) { Value = databaseId },
                new SqlParameter("@ExecutedBy", SqlDbType.NVarChar, 100) { Value = executedBy },
                new SqlParameter("@ParametersUsed", SqlDbType.NVarChar, -1) { Value = (object)parametersUsed ?? DBNull.Value },
                new SqlParameter("@Success", SqlDbType.Bit) { Value = success },
                new SqlParameter("@ErrorMessage", SqlDbType.NVarChar, -1) { Value = (object)errorMessage ?? DBNull.Value },
                new SqlParameter("@RowsReturned", SqlDbType.Int) { Value = (object)rowsReturned ?? DBNull.Value }
            };

            DatabaseHelper.ExecuteNonQuery("usp_LogScriptExecution", parameters);
        }

        #endregion
    }
}
