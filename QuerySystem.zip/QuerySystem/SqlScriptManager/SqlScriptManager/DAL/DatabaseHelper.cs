using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SqlScriptManager.DAL
{
    /// <summary>
    /// Provides low-level database connectivity and command execution helpers.
    /// </summary>
    public static class DatabaseHelper
    {
        /// <summary>
        /// Gets the application database connection string from Web.config.
        /// </summary>
        public static string AppConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["AppDb"].ConnectionString; }
        }

        /// <summary>
        /// Creates and returns an open SqlConnection to the application database.
        /// </summary>
        public static SqlConnection GetAppConnection()
        {
            var conn = new SqlConnection(AppConnectionString);
            conn.Open();
            return conn;
        }

        /// <summary>
        /// Executes a stored procedure and returns a DataTable.
        /// </summary>
        public static DataTable ExecuteStoredProcedure(string procedureName, params SqlParameter[] parameters)
        {
            var dt = new DataTable();
            using (var conn = GetAppConnection())
            using (var cmd = new SqlCommand(procedureName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 60;
                if (parameters != null)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                using (var adapter = new SqlDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                }
            }
            return dt;
        }

        /// <summary>
        /// Executes a stored procedure and returns a scalar value.
        /// </summary>
        public static object ExecuteScalar(string procedureName, params SqlParameter[] parameters)
        {
            using (var conn = GetAppConnection())
            using (var cmd = new SqlCommand(procedureName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 60;
                if (parameters != null)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                return cmd.ExecuteScalar();
            }
        }

        /// <summary>
        /// Executes a stored procedure with no return (INSERT/UPDATE/DELETE).
        /// </summary>
        public static int ExecuteNonQuery(string procedureName, params SqlParameter[] parameters)
        {
            using (var conn = GetAppConnection())
            using (var cmd = new SqlCommand(procedureName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 60;
                if (parameters != null)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                return cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Executes a T-SQL query on a target database and returns results as a DataTable.
        /// Uses integrated security or SQL authentication based on credentials.
        /// </summary>
        public static DataTable ExecuteQueryOnTarget(string baseConnectionString, string sqlQuery, UserCredentials credentials, int timeoutSeconds = 120)
        {
            string connectionString = BuildTargetConnectionString(baseConnectionString, credentials);
            var dt = new DataTable();

            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(sqlQuery, conn))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = timeoutSeconds;
                    using (var adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(dt);
                    }
                }
            }
            return dt;
        }

        /// <summary>
        /// Builds the target connection string, injecting user credentials if provided.
        /// </summary>
        private static string BuildTargetConnectionString(string baseConnectionString, UserCredentials credentials)
        {
            if (credentials == null || !credentials.HasCredentials)
            {
                return baseConnectionString;
            }

            // Replace integrated security with SQL auth credentials
            var builder = new SqlConnectionStringBuilder(baseConnectionString);
            builder.IntegratedSecurity = false;
            builder.UserID = credentials.Username;
            builder.Password = credentials.Password;
            return builder.ConnectionString;
        }
    }
}
