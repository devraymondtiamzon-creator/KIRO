using System;

namespace SqlScriptManager.DAL
{
    /// <summary>
    /// Represents a saved T-SQL script.
    /// </summary>
    public class ScriptModel
    {
        public int ScriptID { get; set; }
        public string ScriptName { get; set; }
        public string Description { get; set; }
        public int DatabaseID { get; set; }
        public string DatabaseName { get; set; }
        public string ScriptText { get; set; }
        public string CreatedBy { get; set; }
        public DateTime DateCreated { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? DateUpdated { get; set; }
    }

    /// <summary>
    /// Represents a target database entry.
    /// </summary>
    public class DatabaseModel
    {
        public int DatabaseID { get; set; }
        public string DatabaseName { get; set; }
        public string ServerName { get; set; }
        public string ConnectionString { get; set; }
    }

    /// <summary>
    /// Represents a script execution log entry.
    /// </summary>
    public class ExecutionLogModel
    {
        public int LogID { get; set; }
        public int ScriptID { get; set; }
        public int DatabaseID { get; set; }
        public string ExecutedBy { get; set; }
        public DateTime ExecutionDate { get; set; }
        public string ParametersUsed { get; set; }
        public bool Success { get; set; }
        public string ErrorMessage { get; set; }
        public int? RowsReturned { get; set; }
    }

    /// <summary>
    /// Holds user-provided credentials for script execution.
    /// </summary>
    public class UserCredentials
    {
        public string Username { get; set; }
        public string Password { get; set; }

        /// <summary>
        /// Returns true if credentials were provided (not using integrated security).
        /// </summary>
        public bool HasCredentials
        {
            get { return !string.IsNullOrWhiteSpace(Username) && !string.IsNullOrWhiteSpace(Password); }
        }
    }
}
