// ============================================
// SQL Script Manager - Client-Side Scripts
// ============================================

/**
 * Shows a modal popup by adding the 'active' class.
 * @param {string} modalId - The ID of the modal overlay element.
 */
function showModal(modalId) {
    var modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
    }
}

/**
 * Hides a modal popup by removing the 'active' class.
 * @param {string} modalId - The ID of the modal overlay element.
 */
function hideModal(modalId) {
    var modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
    }
}

/**
 * Prompts the user for each parameter found in the script.
 * Parameters are identified by the &parameterName pattern.
 * @param {string} scriptText - The T-SQL script text.
 * @returns {object|null} Dictionary of parameter names and values, or null if cancelled.
 */
function promptForParameters(scriptText) {
    if (!scriptText) return {};

    var regex = /&(\w+)/g;
    var match;
    var params = [];
    var seen = {};

    // Extract unique parameters
    while ((match = regex.exec(scriptText)) !== null) {
        var paramName = match[1];
        if (!seen[paramName]) {
            seen[paramName] = true;
            params.push(paramName);
        }
    }

    if (params.length === 0) return {};

    var values = {};
    for (var i = 0; i < params.length; i++) {
        var value = prompt('Enter value for parameter: ' + params[i], '');
        if (value === null) {
            // User cancelled
            return null;
        }
        values[params[i]] = value;
    }

    return values;
}

/**
 * Confirms a delete action.
 * @param {string} scriptName - Name of the script being deleted.
 * @returns {boolean} True if user confirms.
 */
function confirmDelete(scriptName) {
    return confirm('Are you sure you want to delete the script "' + scriptName + '"?');
}

/**
 * Validates that required fields are filled in.
 * @param {string[]} fieldIds - Array of element IDs to validate.
 * @returns {boolean} True if all fields have values.
 */
function validateRequiredFields(fieldIds) {
    var valid = true;
    for (var i = 0; i < fieldIds.length; i++) {
        var field = document.getElementById(fieldIds[i]);
        if (field && !field.value.trim()) {
            field.style.borderColor = '#e74c3c';
            valid = false;
        } else if (field) {
            field.style.borderColor = '#dcdfe3';
        }
    }
    if (!valid) {
        alert('Please fill in all required fields.');
    }
    return valid;
}
