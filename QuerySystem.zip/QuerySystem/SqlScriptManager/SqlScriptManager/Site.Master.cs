using System;
using System.Web.UI;

namespace SqlScriptManager
{
    public partial class SiteMaster : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Highlight active navigation link based on current page path
            string currentPath = Request.Path.ToLower();

            if (currentPath.Contains("/admin/"))
            {
                lnkAdmin.Attributes["class"] = "active";
            }
            else if (currentPath.Contains("/user/"))
            {
                lnkUser.Attributes["class"] = "active";
            }
        }
    }
}
