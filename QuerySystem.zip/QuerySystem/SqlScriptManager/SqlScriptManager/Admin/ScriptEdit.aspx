<%@ Page Title="Script Editor" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" 
    CodeBehind="ScriptEdit.aspx.cs" Inherits="SqlScriptManager.Admin.ScriptEdit" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">

    <div class="page-header">
        <h2><asp:Label ID="lblPageTitle" runat="server" Text="Add New Script" /></h2>
        <asp:Button ID="btnBack" runat="server" Text="&larr; Back to List" CssClass="btn btn-secondary" 
            OnClick="btnBack_Click" CausesValidation="false" />
    </div>

    <!-- Status Message -->
    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <!-- Script Edit Form -->
    <div class="panel">
        <div class="panel-header">Script Details</div>

        <asp:HiddenField ID="hdnScriptID" runat="server" Value="0" />

        <div class="form-group">
            <label for="<%= txtScriptName.ClientID %>">Script Name <span style="color:#e74c3c;">*</span></label>
            <asp:TextBox ID="txtScriptName" runat="server" CssClass="form-control" MaxLength="200" 
                placeholder="Enter a descriptive name for the script" />
            <asp:RequiredFieldValidator ID="rfvScriptName" runat="server" ControlToValidate="txtScriptName"
                ErrorMessage="Script Name is required." Display="Dynamic" ForeColor="Red" 
                ValidationGroup="SaveScript" />
        </div>

        <div class="form-group">
            <label for="<%= txtDescription.ClientID %>">Description</label>
            <asp:TextBox ID="txtDescription" runat="server" CssClass="form-control" TextMode="MultiLine" 
                Rows="3" MaxLength="1000" placeholder="Brief description of what this script does" />
        </div>

        <div class="form-group">
            <label for="<%= ddlDatabase.ClientID %>">Database <span style="color:#e74c3c;">*</span></label>
            <asp:DropDownList ID="ddlDatabase" runat="server" CssClass="form-control">
            </asp:DropDownList>
            <asp:RequiredFieldValidator ID="rfvDatabase" runat="server" ControlToValidate="ddlDatabase"
                InitialValue="" ErrorMessage="Please select a database." Display="Dynamic" ForeColor="Red" 
                ValidationGroup="SaveScript" />
        </div>

        <div class="form-group">
            <label for="<%= txtScript.ClientID %>">T-SQL Script <span style="color:#e74c3c;">*</span></label>
            <asp:TextBox ID="txtScript" runat="server" CssClass="form-control" TextMode="MultiLine" 
                Rows="12" placeholder="Enter your T-SQL script here. Use &parameterName for parameters in WHERE clauses. Example: WHERE EmployeeID = &empId" />
            <asp:RequiredFieldValidator ID="rfvScript" runat="server" ControlToValidate="txtScript"
                ErrorMessage="Script text is required." Display="Dynamic" ForeColor="Red" 
                ValidationGroup="SaveScript" />
            <div class="text-muted mt-10">
                <strong>Tip:</strong> Use <code>&amp;parameterName</code> syntax for dynamic parameters. 
                Example: <code>WHERE Status = &amp;status AND DeptID = &amp;deptId</code>
            </div>
        </div>

        <!-- Action Buttons -->
        <div style="margin-top: 20px; display: flex; gap: 10px;">
            <asp:Button ID="btnTest" runat="server" Text="Test Script" CssClass="btn btn-warning" 
                OnClick="btnTest_Click" CausesValidation="false" />
            <asp:Button ID="btnSave" runat="server" Text="Save Script" CssClass="btn btn-success" 
                OnClick="btnSave_Click" ValidationGroup="SaveScript" />
            <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn btn-secondary" 
                OnClick="btnBack_Click" CausesValidation="false" />
        </div>
    </div>

    <!-- Parameter Input Panel (shown when Test is clicked and parameters exist) -->
    <asp:Panel ID="pnlParameters" runat="server" Visible="false" CssClass="panel">
        <div class="panel-header">Enter Parameter Values</div>
        <asp:Repeater ID="rptParameters" runat="server">
            <ItemTemplate>
                <div class="form-group">
                    <label><%# Container.DataItem.ToString() %></label>
                    <asp:TextBox ID="txtParamValue" runat="server" CssClass="form-control" 
                        placeholder='<%# "Enter value for " + Container.DataItem.ToString() %>' />
                    <asp:HiddenField ID="hdnParamName" runat="server" Value='<%# Container.DataItem.ToString() %>' />
                </div>
            </ItemTemplate>
        </asp:Repeater>
        <div style="margin-top: 16px;">
            <asp:Button ID="btnExecuteTest" runat="server" Text="Execute Test" CssClass="btn btn-primary" 
                OnClick="btnExecuteTest_Click" CausesValidation="false" />
        </div>
    </asp:Panel>

    <!-- Results Panel -->
    <asp:Panel ID="pnlResults" runat="server" Visible="false" CssClass="panel">
        <div class="panel-header">
            Test Results
            <asp:Label ID="lblRowCount" runat="server" CssClass="text-muted" style="font-size: 13px; margin-left: 10px;" />
        </div>
        <div class="results-container">
            <asp:GridView ID="gvResults" runat="server" AutoGenerateColumns="true" 
                CssClass="data-grid" GridLines="None" 
                EmptyDataText="Query returned no results." />
        </div>
    </asp:Panel>

</asp:Content>
