using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using SqlScriptManager.DAL;

namespace SqlScriptManager.Admin
{
    public partial class ScriptEdit : Page
    {
        private bool IsEditMode
        {
            get { return Request.QueryString["mode"] == "edit"; }
        }

        private int ScriptID
        {
            get
            {
                int id;
                if (int.TryParse(Request.QueryString["id"], out id))
                    return id;
                return 0;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadDatabases();

                if (IsEditMode && ScriptID > 0)
                {
                    LoadScript(ScriptID);
                    lblPageTitle.Text = "Edit Script";
                    Page.Title = "Edit Script";
                }
                else
                {
                    lblPageTitle.Text = "Add New Script";
                    Page.Title = "Add New Script";
                }
            }
        }

        /// <summary>
        /// Loads the database dropdown with active databases.
        /// </summary>
        private void LoadDatabases()
        {
            try
            {
                var dt = ScriptRepository.GetActiveDatabases();
                ddlDatabase.DataSource = dt;
                ddlDatabase.DataTextField = "DatabaseName";
                ddlDatabase.DataValueField = "DatabaseID";
                ddlDatabase.DataBind();
                ddlDatabase.Items.Insert(0, new ListItem("-- Select Database --", ""));
            }
            catch (Exception ex)
            {
                ShowMessage("Error loading databases: " + ex.Message, "message message-error");
            }
        }

        /// <summary>
        /// Loads an existing script for editing.
        /// </summary>
        private void LoadScript(int scriptId)
        {
            try
            {
                var script = ScriptRepository.GetScriptByID(scriptId);
                if (script == null)
                {
                    ShowMessage("Script not found.", "message message-error");
                    return;
                }

                hdnScriptID.Value = script.ScriptID.ToString();
                txtScriptName.Text = script.ScriptName;
                txtDescription.Text = script.Description;
                ddlDatabase.SelectedValue = script.DatabaseID.ToString();
                txtScript.Text = script.ScriptText;
            }
            catch (Exception ex)
            {
                ShowMessage("Error loading script: " + ex.Message, "message message-error");
            }
        }

        /// <summary>
        /// Handles the Test button click - detects parameters and shows input panel.
        /// </summary>
        protected void btnTest_Click(object sender, EventArgs e)
        {
            string scriptText = txtScript.Text.Trim();
            if (string.IsNullOrEmpty(scriptText))
            {
                ShowMessage("Please enter a script to test.", "message message-error");
                return;
            }

            if (string.IsNullOrEmpty(ddlDatabase.SelectedValue))
            {
                ShowMessage("Please select a database before testing.", "message message-error");
                return;
            }

            // Extract parameters from script
            var parameters = ScriptRepository.ExtractParameters(scriptText);

            if (parameters.Count > 0)
            {
                // Show parameter input panel
                rptParameters.DataSource = parameters;
                rptParameters.DataBind();
                pnlParameters.Visible = true;
                pnlResults.Visible = false;
            }
            else
            {
                // No parameters - execute directly
                ExecuteTestQuery(new Dictionary<string, string>());
            }
        }

        /// <summary>
        /// Handles the Execute Test button click after parameters are provided.
        /// </summary>
        protected void btnExecuteTest_Click(object sender, EventArgs e)
        {
            var paramValues = new Dictionary<string, string>();

            // Collect parameter values from the repeater
            foreach (RepeaterItem item in rptParameters.Items)
            {
                var hdnParamName = (HiddenField)item.FindControl("hdnParamName");
                var txtParamValue = (TextBox)item.FindControl("txtParamValue");

                if (hdnParamName != null && txtParamValue != null)
                {
                    paramValues[hdnParamName.Value] = txtParamValue.Text.Trim();
                }
            }

            ExecuteTestQuery(paramValues);
        }

        /// <summary>
        /// Executes the test query on the target database and displays results.
        /// </summary>
        private void ExecuteTestQuery(Dictionary<string, string> paramValues)
        {
            try
            {
                string scriptText = txtScript.Text.Trim();
                int databaseId = Convert.ToInt32(ddlDatabase.SelectedValue);
                string currentUser = GetCurrentUser();

                // Use ScriptID 0 for unsaved scripts during testing
                int scriptId = 0;
                int.TryParse(hdnScriptID.Value, out scriptId);

                var results = ScriptRepository.ExecuteScript(
                    scriptId, databaseId, scriptText, paramValues, null, currentUser);

                // Display results
                gvResults.DataSource = results;
                gvResults.DataBind();

                pnlResults.Visible = true;
                lblRowCount.Text = string.Format("({0} row{1} returned)", 
                    results.Rows.Count, results.Rows.Count == 1 ? "" : "s");

                ShowMessage("Script executed successfully.", "message message-success");
            }
            catch (Exception ex)
            {
                pnlResults.Visible = false;
                ShowMessage("Execution error: " + ex.Message, "message message-error");
            }
        }

        /// <summary>
        /// Saves the script (insert or update).
        /// </summary>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid)
                return;

            try
            {
                string scriptName = txtScriptName.Text.Trim();
                string description = txtDescription.Text.Trim();
                int databaseId = Convert.ToInt32(ddlDatabase.SelectedValue);
                string scriptText = txtScript.Text.Trim();
                string currentUser = GetCurrentUser();

                if (IsEditMode && ScriptID > 0)
                {
                    // Update existing script
                    ScriptRepository.UpdateScript(ScriptID, scriptName, description, databaseId, scriptText, currentUser);
                    Response.Redirect("ScriptList.aspx?msg=Script updated successfully.", false);
                }
                else
                {
                    // Insert new script
                    ScriptRepository.InsertScript(scriptName, description, databaseId, scriptText, currentUser);
                    Response.Redirect("ScriptList.aspx?msg=Script saved successfully.", false);
                }
            }
            catch (Exception ex)
            {
                ShowMessage("Error saving script: " + ex.Message, "message message-error");
            }
        }

        /// <summary>
        /// Navigates back to the script list.
        /// </summary>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("ScriptList.aspx");
        }

        /// <summary>
        /// Shows a status message.
        /// </summary>
        private void ShowMessage(string text, string cssClass)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = cssClass;
            lblMessage.Text = text;
        }

        /// <summary>
        /// Gets the current user identity.
        /// </summary>
        private string GetCurrentUser()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
                return User.Identity.Name;

            return Environment.UserName;
        }
    }
}
