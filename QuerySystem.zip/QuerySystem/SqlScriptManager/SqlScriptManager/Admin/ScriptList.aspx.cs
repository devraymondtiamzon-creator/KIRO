using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using SqlScriptManager.DAL;

namespace SqlScriptManager.Admin
{
    public partial class ScriptList : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();

                // Check for messages from redirect (after save/update)
                if (!string.IsNullOrEmpty(Request.QueryString["msg"]))
                {
                    ShowMessage(Request.QueryString["msg"], "message message-success");
                }
            }
        }

        /// <summary>
        /// Binds the scripts grid with optional search filtering.
        /// </summary>
        private void BindGrid(string searchTerm = null)
        {
            try
            {
                var dt = ScriptRepository.GetAllScripts(searchTerm);
                gvScripts.DataSource = dt;
                gvScripts.DataBind();
            }
            catch (Exception ex)
            {
                ShowMessage("Error loading scripts: " + ex.Message, "message message-error");
            }
        }

        /// <summary>
        /// Navigate to the Add Script page.
        /// </summary>
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            Response.Redirect("ScriptEdit.aspx?mode=add");
        }

        /// <summary>
        /// Searches scripts based on the search term.
        /// </summary>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindGrid(txtSearch.Text.Trim());
        }

        /// <summary>
        /// Clears the search and reloads all scripts.
        /// </summary>
        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Text = string.Empty;
            BindGrid();
        }

        /// <summary>
        /// Handles grid row commands (Edit, Delete).
        /// </summary>
        protected void gvScripts_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int scriptId = Convert.ToInt32(e.CommandArgument);

            switch (e.CommandName)
            {
                case "EditScript":
                    Response.Redirect("ScriptEdit.aspx?mode=edit&id=" + scriptId);
                    break;

                case "DeleteScript":
                    DeleteScript(scriptId);
                    break;
            }
        }

        /// <summary>
        /// Soft-deletes a script and refreshes the grid.
        /// </summary>
        private void DeleteScript(int scriptId)
        {
            try
            {
                string currentUser = GetCurrentUser();
                ScriptRepository.DeleteScript(scriptId, currentUser);
                ShowMessage("Script deleted successfully.", "message message-success");
                BindGrid(txtSearch.Text.Trim());
            }
            catch (Exception ex)
            {
                ShowMessage("Error deleting script: " + ex.Message, "message message-error");
            }
        }

        /// <summary>
        /// Shows a status message to the user.
        /// </summary>
        private void ShowMessage(string text, string cssClass)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = cssClass;
            lblMessage.Text = text;
        }

        /// <summary>
        /// Gets the current user identity.
        /// </summary>
        private string GetCurrentUser()
        {
            if (User != null && User.Identity != null && User.Identity.IsAuthenticated)
                return User.Identity.Name;

            return Environment.UserName;
        }

        /// <summary>
        /// Truncates text to a maximum length for grid display.
        /// </summary>
        protected string TruncateText(string text, int maxLength)
        {
            if (string.IsNullOrEmpty(text))
                return string.Empty;

            if (text.Length <= maxLength)
                return Server.HtmlEncode(text);

            return Server.HtmlEncode(text.Substring(0, maxLength)) + "...";
        }
    }
}
