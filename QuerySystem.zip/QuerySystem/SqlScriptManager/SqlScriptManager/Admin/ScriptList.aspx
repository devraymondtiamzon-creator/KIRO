<%@ Page Title="Admin - Scripts" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" 
    CodeBehind="ScriptList.aspx.cs" Inherits="SqlScriptManager.Admin.ScriptList" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    
    <div class="page-header">
        <h2>T-SQL Scripts</h2>
        <asp:Button ID="btnAdd" runat="server" Text="+ Add New Script" CssClass="btn btn-primary" 
            OnClick="btnAdd_Click" />
    </div>

    <!-- Search Bar -->
    <div class="search-bar">
        <asp:TextBox ID="txtSearch" runat="server" CssClass="form-control" 
            placeholder="Search by name, description, database, or author..." />
        <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="btn btn-primary" 
            OnClick="btnSearch_Click" />
        <asp:Button ID="btnClear" runat="server" Text="Clear" CssClass="btn btn-secondary" 
            OnClick="btnClear_Click" />
    </div>

    <!-- Status Message -->
    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <!-- Scripts Grid -->
    <div class="grid-container">
        <asp:GridView ID="gvScripts" runat="server" AutoGenerateColumns="false" 
            CssClass="data-grid" GridLines="None" 
            EmptyDataText="No scripts found. Click 'Add New Script' to create one."
            OnRowCommand="gvScripts_RowCommand"
            DataKeyNames="ScriptID">
            <Columns>
                <asp:TemplateField HeaderText="Actions" ItemStyle-CssClass="action-cell">
                    <ItemTemplate>
                        <asp:LinkButton ID="lnkEdit" runat="server" CommandName="EditScript" 
                            CommandArgument='<%# Eval("ScriptID") %>' CssClass="btn btn-sm btn-warning"
                            Text="Edit" />
                        <asp:LinkButton ID="lnkDelete" runat="server" CommandName="DeleteScript" 
                            CommandArgument='<%# Eval("ScriptID") %>' CssClass="btn btn-sm btn-danger"
                            Text="Delete" 
                            OnClientClick='<%# "return confirmDelete(\"" + Eval("ScriptName").ToString().Replace("\"", "\\\"") + "\");" %>' />
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:BoundField DataField="ScriptName" HeaderText="Script Name" />
                <asp:BoundField DataField="Description" HeaderText="Description" />
                <asp:BoundField DataField="DatabaseName" HeaderText="Database" />
                <asp:TemplateField HeaderText="Script" ItemStyle-CssClass="script-text-cell">
                    <ItemTemplate>
                        <span title='<%# Eval("ScriptText") %>'><%# TruncateText(Eval("ScriptText").ToString(), 80) %></span>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:BoundField DataField="CreatedBy" HeaderText="Created By" />
                <asp:BoundField DataField="DateCreated" HeaderText="Date Created" DataFormatString="{0:yyyy-MM-dd HH:mm}" />
                <asp:BoundField DataField="UpdatedBy" HeaderText="Updated By" />
                <asp:BoundField DataField="DateUpdated" HeaderText="Date Updated" DataFormatString="{0:yyyy-MM-dd HH:mm}" />
            </Columns>
        </asp:GridView>
    </div>

</asp:Content>
