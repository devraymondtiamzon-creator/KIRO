-- ============================================
-- SQL Script Manager - Database Schema
-- Target: SQL Server 2014+
-- ============================================

-- Create the application database
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'SqlScriptManagerDb')
BEGIN
    CREATE DATABASE SqlScriptManagerDb;
END
GO

USE SqlScriptManagerDb;
GO

-- ============================================
-- Table: Databases
-- Stores target database connection info
-- ============================================
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Databases]') AND type = 'U')
BEGIN
    CREATE TABLE [dbo].[Databases]
    (
        [DatabaseID]        INT IDENTITY(1,1) NOT NULL,
        [DatabaseName]      NVARCHAR(200)     NOT NULL,
        [ServerName]        NVARCHAR(200)     NOT NULL,
        [ConnectionString]  NVARCHAR(1000)    NOT NULL,
        [IsActive]          BIT               NOT NULL DEFAULT 1,
        [CreatedBy]         NVARCHAR(100)     NOT NULL,
        [DateCreated]       DATETIME          NOT NULL DEFAULT GETDATE(),
        [UpdatedBy]         NVARCHAR(100)     NULL,
        [DateUpdated]       DATETIME          NULL,
        CONSTRAINT [PK_Databases] PRIMARY KEY CLUSTERED ([DatabaseID] ASC)
    );
END
GO

-- ============================================
-- Table: Scripts
-- Stores T-SQL scripts with metadata
-- ============================================
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Scripts]') AND type = 'U')
BEGIN
    CREATE TABLE [dbo].[Scripts]
    (
        [ScriptID]          INT IDENTITY(1,1) NOT NULL,
        [ScriptName]        NVARCHAR(200)     NOT NULL,
        [Description]       NVARCHAR(1000)    NULL,
        [DatabaseID]        INT               NOT NULL,
        [ScriptText]        NVARCHAR(MAX)     NOT NULL,
        [IsActive]          BIT               NOT NULL DEFAULT 1,
        [CreatedBy]         NVARCHAR(100)     NOT NULL,
        [DateCreated]       DATETIME          NOT NULL DEFAULT GETDATE(),
        [UpdatedBy]         NVARCHAR(100)     NULL,
        [DateUpdated]       DATETIME          NULL,
        CONSTRAINT [PK_Scripts] PRIMARY KEY CLUSTERED ([ScriptID] ASC),
        CONSTRAINT [FK_Scripts_Databases] FOREIGN KEY ([DatabaseID]) 
            REFERENCES [dbo].[Databases]([DatabaseID])
    );
END
GO

-- ============================================
-- Table: ScriptExecutionLog
-- Audit trail for script executions
-- ============================================
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScriptExecutionLog]') AND type = 'U')
BEGIN
    CREATE TABLE [dbo].[ScriptExecutionLog]
    (
        [LogID]             INT IDENTITY(1,1) NOT NULL,
        [ScriptID]          INT               NOT NULL,
        [DatabaseID]        INT               NOT NULL,
        [ExecutedBy]        NVARCHAR(100)     NOT NULL,
        [ExecutionDate]     DATETIME          NOT NULL DEFAULT GETDATE(),
        [ParametersUsed]    NVARCHAR(MAX)     NULL,
        [Success]           BIT               NOT NULL DEFAULT 1,
        [ErrorMessage]      NVARCHAR(MAX)     NULL,
        [RowsReturned]      INT               NULL,
        CONSTRAINT [PK_ScriptExecutionLog] PRIMARY KEY CLUSTERED ([LogID] ASC),
        CONSTRAINT [FK_ExecutionLog_Scripts] FOREIGN KEY ([ScriptID]) 
            REFERENCES [dbo].[Scripts]([ScriptID]),
        CONSTRAINT [FK_ExecutionLog_Databases] FOREIGN KEY ([DatabaseID]) 
            REFERENCES [dbo].[Databases]([DatabaseID])
    );
END
GO

-- ============================================
-- Indexes
-- ============================================
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Scripts_ScriptName')
    CREATE NONCLUSTERED INDEX [IX_Scripts_ScriptName] ON [dbo].[Scripts]([ScriptName]);
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Scripts_DatabaseID')
    CREATE NONCLUSTERED INDEX [IX_Scripts_DatabaseID] ON [dbo].[Scripts]([DatabaseID]);
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ScriptExecutionLog_ScriptID')
    CREATE NONCLUSTERED INDEX [IX_ScriptExecutionLog_ScriptID] ON [dbo].[ScriptExecutionLog]([ScriptID]);
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ScriptExecutionLog_ExecutedBy')
    CREATE NONCLUSTERED INDEX [IX_ScriptExecutionLog_ExecutedBy] ON [dbo].[ScriptExecutionLog]([ExecutedBy]);
GO

-- ============================================
-- Sample Data: Insert some target databases
-- ============================================
IF NOT EXISTS (SELECT 1 FROM [dbo].[Databases])
BEGIN
    INSERT INTO [dbo].[Databases] ([DatabaseName], [ServerName], [ConnectionString], [CreatedBy])
    VALUES 
        ('Production DB', 'PROD-SERVER', 'Server=PROD-SERVER;Database=ProductionDb;Integrated Security=True;', 'SYSTEM'),
        ('Development DB', 'DEV-SERVER', 'Server=DEV-SERVER;Database=DevDb;Integrated Security=True;', 'SYSTEM'),
        ('QA DB', 'QA-SERVER', 'Server=QA-SERVER;Database=QADb;Integrated Security=True;', 'SYSTEM');
END
GO

-- ============================================
-- Stored Procedures
-- ============================================

-- Get all scripts with database name (for grid display)
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetAllScripts]') AND type = 'P')
    DROP PROCEDURE [dbo].[usp_GetAllScripts];
GO

CREATE PROCEDURE [dbo].[usp_GetAllScripts]
    @SearchTerm NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        s.ScriptID,
        s.ScriptName,
        s.[Description],
        d.DatabaseName,
        s.ScriptText,
        s.CreatedBy,
        s.DateCreated,
        s.UpdatedBy,
        s.DateUpdated
    FROM [dbo].[Scripts] s
    INNER JOIN [dbo].[Databases] d ON s.DatabaseID = d.DatabaseID
    WHERE s.IsActive = 1
      AND (@SearchTerm IS NULL 
           OR s.ScriptName LIKE '%' + @SearchTerm + '%'
           OR s.[Description] LIKE '%' + @SearchTerm + '%'
           OR d.DatabaseName LIKE '%' + @SearchTerm + '%'
           OR s.CreatedBy LIKE '%' + @SearchTerm + '%')
    ORDER BY s.DateCreated DESC;
END
GO

-- Get script by ID
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetScriptByID]') AND type = 'P')
    DROP PROCEDURE [dbo].[usp_GetScriptByID];
GO

CREATE PROCEDURE [dbo].[usp_GetScriptByID]
    @ScriptID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        s.ScriptID,
        s.ScriptName,
        s.[Description],
        s.DatabaseID,
        d.DatabaseName,
        s.ScriptText,
        s.CreatedBy,
        s.DateCreated,
        s.UpdatedBy,
        s.DateUpdated
    FROM [dbo].[Scripts] s
    INNER JOIN [dbo].[Databases] d ON s.DatabaseID = d.DatabaseID
    WHERE s.ScriptID = @ScriptID;
END
GO

-- Insert script
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_InsertScript]') AND type = 'P')
    DROP PROCEDURE [dbo].[usp_InsertScript];
GO

CREATE PROCEDURE [dbo].[usp_InsertScript]
    @ScriptName     NVARCHAR(200),
    @Description    NVARCHAR(1000),
    @DatabaseID     INT,
    @ScriptText     NVARCHAR(MAX),
    @CreatedBy      NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO [dbo].[Scripts] ([ScriptName], [Description], [DatabaseID], [ScriptText], [CreatedBy])
    VALUES (@ScriptName, @Description, @DatabaseID, @ScriptText, @CreatedBy);

    SELECT SCOPE_IDENTITY() AS NewScriptID;
END
GO

-- Update script
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_UpdateScript]') AND type = 'P')
    DROP PROCEDURE [dbo].[usp_UpdateScript];
GO

CREATE PROCEDURE [dbo].[usp_UpdateScript]
    @ScriptID       INT,
    @ScriptName     NVARCHAR(200),
    @Description    NVARCHAR(1000),
    @DatabaseID     INT,
    @ScriptText     NVARCHAR(MAX),
    @UpdatedBy      NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE [dbo].[Scripts]
    SET [ScriptName]  = @ScriptName,
        [Description] = @Description,
        [DatabaseID]  = @DatabaseID,
        [ScriptText]  = @ScriptText,
        [UpdatedBy]   = @UpdatedBy,
        [DateUpdated] = GETDATE()
    WHERE [ScriptID] = @ScriptID;
END
GO

-- Delete script (soft delete)
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_DeleteScript]') AND type = 'P')
    DROP PROCEDURE [dbo].[usp_DeleteScript];
GO

CREATE PROCEDURE [dbo].[usp_DeleteScript]
    @ScriptID   INT,
    @UpdatedBy  NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE [dbo].[Scripts]
    SET [IsActive]    = 0,
        [UpdatedBy]   = @UpdatedBy,
        [DateUpdated] = GETDATE()
    WHERE [ScriptID] = @ScriptID;
END
GO

-- Get all active databases (for dropdown)
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetActiveDatabases]') AND type = 'P')
    DROP PROCEDURE [dbo].[usp_GetActiveDatabases];
GO

CREATE PROCEDURE [dbo].[usp_GetActiveDatabases]
AS
BEGIN
    SET NOCOUNT ON;

    SELECT [DatabaseID], [DatabaseName], [ServerName], [ConnectionString]
    FROM [dbo].[Databases]
    WHERE [IsActive] = 1
    ORDER BY [DatabaseName];
END
GO

-- Get connection string by database ID
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_GetConnectionString]') AND type = 'P')
    DROP PROCEDURE [dbo].[usp_GetConnectionString];
GO

CREATE PROCEDURE [dbo].[usp_GetConnectionString]
    @DatabaseID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT [ConnectionString], [ServerName], [DatabaseName]
    FROM [dbo].[Databases]
    WHERE [DatabaseID] = @DatabaseID AND [IsActive] = 1;
END
GO

-- Log script execution
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_LogScriptExecution]') AND type = 'P')
    DROP PROCEDURE [dbo].[usp_LogScriptExecution];
GO

CREATE PROCEDURE [dbo].[usp_LogScriptExecution]
    @ScriptID       INT,
    @DatabaseID     INT,
    @ExecutedBy     NVARCHAR(100),
    @ParametersUsed NVARCHAR(MAX) = NULL,
    @Success        BIT = 1,
    @ErrorMessage   NVARCHAR(MAX) = NULL,
    @RowsReturned   INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO [dbo].[ScriptExecutionLog] 
        ([ScriptID], [DatabaseID], [ExecutedBy], [ParametersUsed], [Success], [ErrorMessage], [RowsReturned])
    VALUES 
        (@ScriptID, @DatabaseID, @ExecutedBy, @ParametersUsed, @Success, @ErrorMessage, @RowsReturned);
END
GO

PRINT 'Schema creation completed successfully.';
GO
