using System;
using System.Web;

namespace SqlScriptManager
{
    public class Global : HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            // Application startup logic
        }

        protected void Application_End(object sender, EventArgs e)
        {
            // Application shutdown logic
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            // Global error handling
            Exception ex = Server.GetLastError();

            if (ex != null)
            {
                // Log the error (in production, write to a log file or table)
                System.Diagnostics.Debug.WriteLine("Unhandled Error: " + ex.Message);
                System.Diagnostics.Debug.WriteLine("Stack Trace: " + ex.StackTrace);
            }
        }

        protected void Session_Start(object sender, EventArgs e)
        {
            // Session start logic
        }

        protected void Session_End(object sender, EventArgs e)
        {
            // Session end logic
        }
    }
}
