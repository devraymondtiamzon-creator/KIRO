<%@ Application Codebehind="Global.asax.cs" Inherits="SqlScriptManager.Global" Language="C#" %>
