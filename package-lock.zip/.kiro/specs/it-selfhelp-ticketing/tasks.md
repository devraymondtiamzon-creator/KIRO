# Implementation Plan: IT Self-Help & Smart Ticketing Knowledgebase System

## Overview

This plan implements a full-stack IT Self-Help & Smart Ticketing system using Node.js/TypeScript with Express backend, React frontend, in-memory storage with file persistence, and mock email notifications. Tasks are ordered to build foundation first, then core services, then API layer, then frontend, with tests interspersed close to their implementation targets.

## Tasks

- [x] 1. Project scaffolding and configuration
  - [x] 1.1 Initialize project with package.json and install dependencies
    - Create package.json with scripts for dev, build, test
    - Install Express, React 18, Vite, TypeScript, Vitest, fast-check, tsx, uuid
    - Configure tsconfig.json for both server and client
    - _Requirements: All (foundation for entire system)_

  - [x] 1.2 Configure Vite, Vitest, and project structure
    - Create vite.config.ts with React plugin and proxy to backend
    - Create vitest.config.ts with test paths
    - Create directory structure per design: src/server/, src/client/, tests/unit/, tests/property/, data/
    - _Requirements: All (foundation for entire system)_

- [x] 2. Shared types and in-memory data store
  - [x] 2.1 Define shared type definitions
    - Create src/server/models/types.ts with all interfaces: WizardSession, Ticket, EmailRecord, MaintenanceWindow, PointsEvent, StatusTransition, SmartTag
    - Define enums: WizardStep, SystemType, ImpactLevel, TicketStatus, EmailType, PointsEventType
    - Define EWT_HOURS mapping and POINTS_MAP constant
    - Define VALID_TRANSITIONS map for ticket status lifecycle
    - _Requirements: 1.2, 3.1, 4.1, 4.2, 5.1, 6.1, 10.1_

  - [x] 2.2 Implement in-memory data store with file persistence
    - Create src/server/store/dataStore.ts with Map-based storage for all entities
    - Implement loadFromFile() to restore data from data/store.json on startup
    - Implement saveToFile() to persist data on graceful shutdown (SIGINT/SIGTERM)
    - Implement helper methods: getTickets(), getEmails(), getMaintenanceWindows()
    - _Requirements: 5.4, 6.2_

- [x] 3. Checkpoint - Verify project scaffolding
  - Ensure TypeScript compiles without errors, ask the user if questions arise.

- [x] 4. Implement Wizard Service
  - [x] 4.1 Implement wizard state machine and session management
    - Create src/server/services/wizardService.ts
    - Implement startSession(): creates a new WizardSession at ERROR_DETAILS step
    - Implement advanceStep(sessionId, answer): validates answer, transitions to next step deterministically
    - Implement step-specific question text and options (per design state transitions)
    - Handle SOLUTIONS step: generate up to 2 self-help solutions based on responses
    - Handle RESOLUTION_CHECK step: if resolved, award FCR points; if not resolved, create ticket
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 10.1_

  - [x] 4.2 Implement maintenance window check within wizard flow
    - Create src/server/services/maintenanceService.ts
    - Implement isWithinMaintenanceWindow(system, dateTime, windows) function
    - Integrate check into wizard DATE_TIME step: if match found, transition to MAINTENANCE_HALT
    - Return MaintenanceInfo with downtime duration and scheduled uptime
    - _Requirements: 2.1, 2.2, 2.3_

  - [ ]* 4.3 Write property test: Wizard deterministic transitions (Property 1)
    - **Property 1: Wizard state machine follows deterministic transitions**
    - For any valid session and answer, wizard advances to exactly one next step in correct order
    - **Validates: Requirements 1.2, 1.3, 1.4**

  - [ ]* 4.4 Write property test: Maintenance window halts wizard (Property 2)
    - **Property 2: Maintenance window halts wizard when date overlaps**
    - For any system/dateTime within a maintenance window, wizard halts with correct info
    - **Validates: Requirements 2.1, 2.2**

- [x] 5. Implement Ticket Service and Smart Tagging
  - [x] 5.1 Implement ticket creation and CRUD operations
    - Create src/server/services/ticketService.ts
    - Implement createTicket(wizardSession): generates INC-YYYY-NNNN ID, populates all diagnostic data, sets initial status
    - Implement getTicket(id), getAllTickets()
    - Implement updateTicketStatus(id, newStatus): validates transition against VALID_TRANSITIONS map, appends to statusHistory
    - Implement submitCsatRating(id, rating): stores rating on ticket
    - _Requirements: 3.1, 3.2, 3.3, 6.1, 6.2, 9.2_

  - [x] 5.2 Implement smart tagging engine
    - Create src/server/services/taggingService.ts
    - Implement computeSmartTags(context): checks for RECURRING tag (same system + error within 7 days)
    - Implement ESCALATED tag logic (impactLevel is Team or Entire Department)
    - Integrate tagging into ticket creation flow
    - _Requirements: 4.1, 4.2, 4.3_

  - [ ]* 5.3 Write property test: Ticket creation preserves wizard data (Property 3)
    - **Property 3: Ticket creation preserves all wizard data**
    - For any completed wizard session, created ticket contains all four diagnostic responses and correct format
    - **Validates: Requirements 3.1, 3.2, 3.3**

  - [ ]* 5.4 Write property test: Recurring tag (Property 4)
    - **Property 4: Recurring tag applied for duplicate issues within 7 days**
    - For any ticket with a matching prior ticket in 7 days, RECURRING tag is applied
    - **Validates: Requirements 4.1**

  - [ ]* 5.5 Write property test: Escalated tag (Property 5)
    - **Property 5: Escalated tag applied for high-impact tickets**
    - For any ticket with impactLevel Team or Entire Department, ESCALATED tag is applied
    - **Validates: Requirements 4.2**

  - [ ]* 5.6 Write property test: Status transition validation (Property 13)
    - **Property 13: Ticket status validation rejects invalid transitions**
    - For any ticket with status S and invalid target T, transition is rejected and ticket unchanged
    - **Validates: Requirements 6.1**

- [x] 6. Implement Email and SLA Services
  - [x] 6.1 Implement email service (mock)
    - Create src/server/services/emailService.ts
    - Implement sendEmail(params): logs to console, creates EmailRecord, stores in data store
    - Implement sendAcknowledgmentEmail(ticket): includes EWT based on system type
    - Implement sendStatusUpdateEmail(ticket, newStatus)
    - Implement sendSlaBreachEmail(ticket, revisedEwt)
    - Implement sendReminderEmail(ticket) and sendAutoCloseEmail(ticket)
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 6.3, 7.2, 7.3, 8.1, 8.3_

  - [x] 6.2 Implement SLA monitoring service
    - Create src/server/services/slaService.ts
    - Implement checkSlaBreaches(tickets, now): detects tickets in non-terminal status > 2 days
    - Implement checkAutoClose(tickets, now): detects tickets in For User Acknowledgment > 3 days
    - Implement checkReminders(tickets, now): detects tickets in For User Acknowledgment > 2 days
    - On breach detection: send email, apply ESCALATED tag, deduct performance points
    - _Requirements: 7.1, 7.2, 7.3, 8.1, 8.2, 8.3_

  - [ ]* 6.3 Write property test: EWT mapping (Property 6)
    - **Property 6: EWT mapping produces correct hours for all system types**
    - For any valid system type, acknowledgment email includes correct EWT value
    - **Validates: Requirements 5.1, 5.2, 5.3**

  - [ ]* 6.4 Write property test: Email logging (Property 7)
    - **Property 7: All emails are logged and persisted**
    - For any email-triggering event, an email record is stored in the data store
    - **Validates: Requirements 5.4, 6.3**

  - [ ]* 6.5 Write property test: Status history recording (Property 8)
    - **Property 8: Status transitions record history with timestamps**
    - For any valid status change, a StatusTransition record is appended with correct data
    - **Validates: Requirements 6.2**

  - [ ]* 6.6 Write property test: SLA breach detection (Property 9)
    - **Property 9: SLA breach detection at 2-day threshold**
    - For any ticket in non-terminal status > 2 days, SLA breach is detected
    - **Validates: Requirements 7.1, 7.2, 7.3**

  - [ ]* 6.7 Write property test: Auto-close lifecycle (Property 10)
    - **Property 10: Auto-close lifecycle for unacknowledged tickets**
    - For any ticket in For User Acknowledgment > 3 days, status changes to AUTO CLOSE
    - **Validates: Requirements 8.1, 8.2, 8.3**

- [x] 7. Implement Performance Points Service
  - [x] 7.1 Implement points calculation and tracking
    - Create src/server/services/pointsService.ts
    - Implement awardPoints(ticketId, eventType): creates PointsEvent record
    - Implement calculateCsatPoints(rating): returns correct points per design mapping
    - Implement getTotalPoints(): sums all PointsEvent values
    - Implement getPointsEvents(): returns all events for display
    - Integrate FCR points in wizard (resolved at self-help stage = +15)
    - Integrate resolved-within-EWT check on ticket resolution
    - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5, 10.6_

  - [ ]* 7.2 Write property test: CSAT rating persistence (Property 11)
    - **Property 11: CSAT rating persistence**
    - For any valid CSAT rating 1-5 submitted for a ticket in For User Acknowledgment, rating is stored
    - **Validates: Requirements 9.2**

  - [ ]* 7.3 Write property test: Performance points mapping (Property 12)
    - **Property 12: Performance points mapping is correct for all events**
    - For any scoring event, correct points are awarded/deducted per fixed mapping
    - **Validates: Requirements 10.1, 10.2, 10.3, 10.4, 10.5, 10.6**

- [x] 8. Checkpoint - Verify all services pass tests
  - Ensure all tests pass, ask the user if questions arise.

- [x] 9. Implement API routes
  - [x] 9.1 Implement wizard API routes
    - Create src/server/routes/wizardRoutes.ts
    - POST /api/wizard/start — starts a new wizard session
    - POST /api/wizard/:sessionId/answer — submits answer for current step
    - GET /api/wizard/:sessionId — gets current session state
    - Add input validation middleware for wizard answers
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6_

  - [x] 9.2 Implement ticket API routes
    - Create src/server/routes/ticketRoutes.ts
    - GET /api/tickets — lists all tickets
    - GET /api/tickets/:id — gets ticket details
    - PATCH /api/tickets/:id/status — updates ticket status with validation
    - POST /api/tickets/:id/csat — submits CSAT rating
    - Return appropriate error responses (400, 404, 409)
    - _Requirements: 3.1, 6.1, 6.2, 6.3, 9.1, 9.2_

  - [x] 9.3 Implement email, points, and admin API routes
    - Create src/server/routes/emailRoutes.ts: GET /api/emails with optional ticketId filter
    - Create src/server/routes/pointsRoutes.ts: GET /api/points, GET /api/points/events
    - Create src/server/routes/adminRoutes.ts: GET/POST /api/maintenance-windows, POST /api/admin/sla-check, POST /api/admin/auto-close-check
    - _Requirements: 5.4, 7.1, 8.2, 10.1_

  - [x] 9.4 Implement Express server entry point and middleware
    - Create src/server/index.ts with Express app setup
    - Register all route modules
    - Add JSON body parser, CORS middleware
    - Add error handling middleware with ApiError format
    - Set up graceful shutdown with data persistence
    - Configure background SLA check interval (setInterval)
    - _Requirements: All (server foundation)_

  - [x] 9.5 Create validation middleware
    - Create src/server/middleware/validation.ts
    - Implement validateWizardAnswer(step, answer) per design
    - Implement validateStatusTransition(currentStatus, newStatus)
    - Implement validateCsatRating(rating): must be integer 1-5
    - _Requirements: 1.2, 6.1, 9.2_

- [x] 10. Checkpoint - Verify API layer works end-to-end
  - Ensure all tests pass, ask the user if questions arise.

- [x] 11. Implement React frontend
  - [x] 11.1 Set up React app shell and routing
    - Create src/client/index.html, src/client/main.tsx, src/client/App.tsx
    - Set up React Router with routes: / (wizard), /tickets (list), /tickets/:id (detail), /admin (panel)
    - Create src/client/services/api.ts with fetch wrappers for all API endpoints
    - _Requirements: 1.1, 3.1, 6.1_

  - [x] 11.2 Implement Wizard Flow components
    - Create src/client/components/Wizard/WizardFlow.tsx — orchestrates full wizard interaction
    - Create src/client/components/Wizard/WizardStep.tsx — renders individual step with question/options
    - Handle maintenance halt display with downtime info
    - Handle solutions display and resolution confirmation
    - Show ticket ID when created
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 2.1, 2.2, 2.3_

  - [x] 11.3 Implement Ticket List and Detail components
    - Create src/client/components/Tickets/TicketList.tsx — displays all tickets with status, tags, ID
    - Create src/client/components/Tickets/TicketDetail.tsx — shows full ticket info, status history, allows status updates
    - Display smart tags (RECURRING, ESCALATED) visually
    - _Requirements: 3.1, 4.1, 4.2, 6.1, 6.2_

  - [x] 11.4 Implement CSAT Survey and Admin Panel components
    - Create src/client/components/CSAT/CsatSurvey.tsx — 1-5 star rating widget for tickets in For User Acknowledgment
    - Create src/client/components/Admin/AdminPanel.tsx — shows performance points, email log, maintenance windows management, SLA check triggers
    - _Requirements: 9.1, 9.2, 10.1, 7.1, 8.2_

- [x] 12. Integration and final wiring
  - [x] 12.1 Wire frontend to backend and verify full flow
    - Ensure Vite proxy correctly forwards /api/* to Express backend
    - Verify wizard flow end-to-end: start → answer all steps → ticket creation
    - Verify ticket status updates trigger emails
    - Verify CSAT submission awards points
    - Add npm scripts: "dev" (concurrent server + client), "build", "start"
    - _Requirements: All_

  - [ ]* 12.2 Write integration tests for key flows
    - Test full wizard flow: start session → answer all steps → verify ticket created
    - Test ticket lifecycle: create → update status → verify emails sent
    - Test SLA breach detection: create stale ticket → trigger check → verify breach detected
    - Test auto-close: create ticket in For User Acknowledgment → trigger check → verify closure
    - _Requirements: 1.1, 3.1, 6.1, 7.1, 8.2_

- [x] 13. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design document
- Unit tests validate specific examples and edge cases
- The backend and frontend can be developed in parallel after shared types are defined
- Mock emails are logged to console and stored as records — no actual SMTP required

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1"] },
    { "id": 1, "tasks": ["1.2"] },
    { "id": 2, "tasks": ["2.1"] },
    { "id": 3, "tasks": ["2.2"] },
    { "id": 4, "tasks": ["4.1", "4.2"] },
    { "id": 5, "tasks": ["4.3", "4.4", "5.1", "5.2"] },
    { "id": 6, "tasks": ["5.3", "5.4", "5.5", "5.6", "6.1"] },
    { "id": 7, "tasks": ["6.2", "6.3", "6.4", "6.5"] },
    { "id": 8, "tasks": ["6.6", "6.7", "7.1"] },
    { "id": 9, "tasks": ["7.2", "7.3", "9.5"] },
    { "id": 10, "tasks": ["9.1", "9.2", "9.3"] },
    { "id": 11, "tasks": ["9.4"] },
    { "id": 12, "tasks": ["11.1"] },
    { "id": 13, "tasks": ["11.2", "11.3", "11.4"] },
    { "id": 14, "tasks": ["12.1"] },
    { "id": 15, "tasks": ["12.2"] }
  ]
}
```
