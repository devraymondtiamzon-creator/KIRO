# Requirements Document

## Introduction

The IT Self-Help & Smart Ticketing Knowledgebase System is a web-based application that guides users through interactive self-help diagnostics, automatically creates and tags support tickets when issues remain unresolved, manages the full ticket lifecycle with status notifications and SLA enforcement, and collects customer satisfaction feedback with performance scoring. The system uses a Node.js/TypeScript/Express backend with a React frontend and in-memory/file-based storage.

## Glossary

- **Wizard**: The step-by-step interactive diagnostic interface that collects issue details from the user
- **Ticket**: A support incident record created when self-help troubleshooting does not resolve the user's issue
- **System**: The IT Self-Help & Smart Ticketing Knowledgebase application
- **EWT**: Estimated Waiting Time — the projected duration before a ticket is resolved, based on the affected system type
- **SLA**: Service Level Agreement — the maximum allowed time a ticket may remain in a single status before triggering a breach notification
- **CSAT**: Customer Satisfaction — a post-resolution survey rating from 1 to 5 stars
- **FCR**: First Contact Resolution — when a user's issue is resolved during the initial self-help wizard session without creating a ticket
- **Maintenance_Window**: A scheduled period of planned system downtime for a corporate tool
- **Smart_Tag**: An automatic label applied to a ticket based on recurrence or escalation conditions
- **Status_Transition**: A change from one valid ticket status to another
- **Performance_Points**: A numeric scoring system that rewards timely resolution and penalizes SLA breaches and low satisfaction ratings

## Requirements

### Requirement 1: Self-Help Wizard Interaction

**User Story:** As an IT user, I want to be guided through diagnostic questions one at a time, so that I can systematically describe my issue and receive relevant self-help solutions.

#### Acceptance Criteria

1. WHEN a user initiates a self-help session, THE Wizard SHALL present the Error Details question asking for the specific error message or behavior observed.
2. WHEN the user submits the Error Details response, THE Wizard SHALL present the System Affected question with options: Network, Email, ERP, VPN, or Other Corporate Tools.
3. WHEN the user submits the System Affected response, THE Wizard SHALL present the Date and Time question asking when the issue started.
4. WHEN the user submits the Date and Time response, THE Wizard SHALL present the Impact Level question with options: Single User, Team, or Entire Department.
5. WHEN the user completes all four diagnostic questions, THE Wizard SHALL evaluate the responses and propose up to 2 relevant self-help solutions.
6. WHEN self-help solutions are presented, THE Wizard SHALL ask the user whether the issue is resolved.

### Requirement 2: Maintenance Window Check

**User Story:** As an IT user, I want to be informed if my issue coincides with scheduled maintenance, so that I do not waste time troubleshooting a planned outage.

#### Acceptance Criteria

1. WHEN the user-provided Date and Time falls within a scheduled Maintenance_Window for the selected system, THE Wizard SHALL halt the troubleshooting flow.
2. WHEN the Wizard halts due to a Maintenance_Window match, THE Wizard SHALL display the scheduled downtime duration to the user.
3. WHEN the Wizard halts due to a Maintenance_Window match, THE Wizard SHALL advise the user to retry after the scheduled uptime.

### Requirement 3: Ticket Creation

**User Story:** As an IT user, I want a support ticket to be automatically created when self-help does not resolve my issue, so that my problem is formally tracked for resolution.

#### Acceptance Criteria

1. WHEN the user indicates the issue is not resolved after self-help solutions, THE System SHALL create a new ticket with a unique mock ID in the format INC-YYYY-NNNN (e.g., INC-2026-8891).
2. WHEN a ticket is created, THE System SHALL populate the ticket with all diagnostic information collected during the Wizard session.
3. WHEN a ticket is created, THE System SHALL set the initial status to Acknowledge For Evaluation.

### Requirement 4: Smart Tagging

**User Story:** As an IT support team member, I want tickets to be automatically tagged based on recurrence and escalation patterns, so that high-priority issues are identified without manual triage.

#### Acceptance Criteria

1. WHEN a ticket is created and an identical issue (same system affected and same error details) occurred within the past 7 days, THE System SHALL apply the [RECURRING] Smart_Tag to the ticket.
2. WHEN a ticket is created and the Impact Level is Team or Entire Department, THE System SHALL apply the [ESCALATED] Smart_Tag to the ticket.
3. WHEN a ticket breaches the normal resolution EWT, THE System SHALL apply the [ESCALATED] Smart_Tag to the ticket.

### Requirement 5: Acknowledgment Email with EWT

**User Story:** As an IT user, I want to receive an acknowledgment email with an estimated resolution time after my ticket is created, so that I know my issue is being handled and when to expect resolution.

#### Acceptance Criteria

1. WHEN a ticket is created for a Network issue, THE System SHALL draft an acknowledgment email with an EWT of 4 hours.
2. WHEN a ticket is created for an Email issue, THE System SHALL draft an acknowledgment email with an EWT of 2 hours.
3. WHEN a ticket is created for an ERP, VPN, or Other Corporate Tools issue, THE System SHALL draft an acknowledgment email with an EWT based on the system type defaults.
4. THE System SHALL log all email notifications to the console and store them as data records without sending actual emails.

### Requirement 6: Ticket Lifecycle Status Management

**User Story:** As an IT support team member, I want to manage ticket statuses through a defined lifecycle, so that ticket progress is tracked consistently.

#### Acceptance Criteria

1. THE System SHALL support the following valid ticket statuses: Acknowledge For Evaluation, Resource Assignment, Investigation Ongoing, Resolution Ongoing, For Documentation of RCA, For User Acknowledgment, CANCELLED TICKET, AUTO CLOSE, FOR SCHEDULE OF VISIT, WAITING DEVELOPER RESPONSE.
2. WHEN a ticket status is changed, THE System SHALL record the new status and the timestamp of the transition.
3. WHEN a ticket status is changed, THE System SHALL generate an email notification to the user informing them of the new status.

### Requirement 7: SLA Breach Detection and Notification

**User Story:** As an IT user, I want to be notified if my ticket is stuck without progress, so that I am informed of delays and given a revised timeline.

#### Acceptance Criteria

1. WHILE a ticket remains in any single status (except For User Acknowledgment) for more than 2 days, THE System SHALL detect an SLA breach condition.
2. WHEN an SLA breach is detected, THE System SHALL generate an apologetic email notification to the user.
3. WHEN an SLA breach is detected, THE System SHALL include a revised EWT in the notification email.

### Requirement 8: User Acknowledgment and Auto-Close

**User Story:** As an IT support team member, I want tickets awaiting user acknowledgment to auto-close after inactivity, so that resolved issues do not remain open indefinitely.

#### Acceptance Criteria

1. WHILE a ticket is in For User Acknowledgment status for 2 days without user response, THE System SHALL send a reminder warning email to the user.
2. WHILE a ticket is in For User Acknowledgment status for 3 days without user response, THE System SHALL automatically change the ticket status to AUTO CLOSE.
3. WHEN a ticket is auto-closed, THE System SHALL send a final notification email informing the user of the closure.

### Requirement 9: CSAT Survey

**User Story:** As an IT user, I want to provide a satisfaction rating after my issue is resolved, so that the support team can measure and improve service quality.

#### Acceptance Criteria

1. WHEN a ticket status is changed to For User Acknowledgment, THE System SHALL present a CSAT survey with a 1 to 5 star rating scale.
2. WHEN the user submits a CSAT rating, THE System SHALL store the rating associated with the corresponding ticket.

### Requirement 10: Performance Points Calculation

**User Story:** As an IT support team member, I want performance metrics to be calculated automatically, so that resolution quality and efficiency are tracked objectively.

#### Acceptance Criteria

1. WHEN an issue is resolved during the initial Wizard session (FCR), THE System SHALL award +15 Performance_Points.
2. WHEN a ticket is resolved within the initial EWT, THE System SHALL award +10 Performance_Points.
3. WHEN an SLA breach occurs (ticket stagnation exceeding 2 days in a single status), THE System SHALL deduct 10 Performance_Points.
4. WHEN a user submits a CSAT rating of 5 stars, THE System SHALL award +10 Performance_Points.
5. WHEN a user submits a CSAT rating of 4 stars, THE System SHALL award +5 Performance_Points.
6. WHEN a user submits a CSAT rating of 1 or 2 stars, THE System SHALL deduct 5 Performance_Points.
