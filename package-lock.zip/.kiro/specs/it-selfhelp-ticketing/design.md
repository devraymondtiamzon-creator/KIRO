# Design Document: IT Self-Help & Smart Ticketing Knowledgebase System

## High-Level Architecture

The system follows a layered architecture with clear separation between presentation, business logic, and data persistence.

```
┌─────────────────────────────────────────────────────────┐
│                   React Frontend (SPA)                    │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌───────────┐  │
│  │  Wizard  │ │  Ticket  │ │  CSAT    │ │  Admin    │  │
│  │  Flow    │ │  View    │ │  Survey  │ │  Panel    │  │
│  └──────────┘ └──────────┘ └──────────┘ └───────────┘  │
└────────────────────────┬────────────────────────────────┘
                         │ HTTP REST
┌────────────────────────┴────────────────────────────────┐
│                Express API Server (Node.js/TS)           │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌───────────┐  │
│  │  Wizard  │ │  Ticket  │ │  Email   │ │  Points   │  │
│  │  Router  │ │  Router  │ │  Router  │ │  Router   │  │
│  └─────┬────┘ └─────┬────┘ └────┬─────┘ └─────┬─────┘  │
│  ┌─────┴────┐ ┌─────┴────┐ ┌────┴─────┐ ┌─────┴─────┐  │
│  │  Wizard  │ │  Ticket  │ │  Email   │ │  Points   │  │
│  │  Service │ │  Service │ │  Service │ │  Service  │  │
│  └─────┬────┘ └─────┬────┘ └────┬─────┘ └─────┬─────┘  │
│        │             │           │              │        │
│  ┌─────┴─────────────┴───────────┴──────────────┴─────┐  │
│  │              In-Memory Data Store                    │  │
│  │  (with periodic JSON file persistence)              │  │
│  └─────────────────────────────────────────────────────┘  │
│                                                          │
│  ┌─────────────────────────────────────────────────────┐  │
│  │         Background Job Scheduler (setInterval)       │  │
│  │   • SLA breach detection                            │  │
│  │   • Auto-close check                               │  │
│  │   • Reminder emails                                 │  │
│  └─────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────┘
```

### Technology Stack

- **Runtime**: Node.js 20+ with TypeScript 5+
- **Backend Framework**: Express.js
- **Frontend Framework**: React 18 with TypeScript
- **Build Tools**: Vite (frontend), tsx (backend dev), tsc (production build)
- **Testing**: Vitest with fast-check for property-based testing
- **Storage**: In-memory Maps with JSON file backup on shutdown
- **Communication**: REST API with JSON payloads

---

## Component Design

### 1. Wizard Service

Manages the step-by-step diagnostic flow as a finite state machine.

```typescript
// src/server/services/wizardService.ts

enum WizardStep {
  ERROR_DETAILS = 'ERROR_DETAILS',
  SYSTEM_AFFECTED = 'SYSTEM_AFFECTED',
  DATE_TIME = 'DATE_TIME',
  IMPACT_LEVEL = 'IMPACT_LEVEL',
  SOLUTIONS = 'SOLUTIONS',
  RESOLUTION_CHECK = 'RESOLUTION_CHECK',
  MAINTENANCE_HALT = 'MAINTENANCE_HALT',
  COMPLETED = 'COMPLETED',
}

interface WizardSession {
  id: string;
  currentStep: WizardStep;
  responses: {
    errorDetails?: string;
    systemAffected?: SystemType;
    dateTime?: string;
    impactLevel?: ImpactLevel;
  };
  solutions: string[];
  resolved: boolean | null;
  createdAt: string;
}

type SystemType = 'Network' | 'Email' | 'ERP' | 'VPN' | 'Other Corporate Tools';
type ImpactLevel = 'Single User' | 'Team' | 'Entire Department';

interface WizardStepResult {
  sessionId: string;
  currentStep: WizardStep;
  question?: string;
  options?: string[];
  solutions?: string[];
  maintenanceInfo?: MaintenanceInfo;
}

interface MaintenanceInfo {
  system: SystemType;
  downtimeDuration: string;
  scheduledUptime: string;
  message: string;
}
```

**State Transitions:**
```
ERROR_DETAILS → SYSTEM_AFFECTED → DATE_TIME → IMPACT_LEVEL → SOLUTIONS → RESOLUTION_CHECK → COMPLETED
                                      │
                                      └→ MAINTENANCE_HALT (if window match)
```

### 2. Ticket Service

Handles ticket CRUD, status transitions, and smart tagging.

```typescript
// src/server/services/ticketService.ts

interface Ticket {
  id: string; // Format: INC-YYYY-NNNN
  errorDetails: string;
  systemAffected: SystemType;
  dateTime: string;
  impactLevel: ImpactLevel;
  status: TicketStatus;
  tags: SmartTag[];
  ewt: number; // in hours
  statusHistory: StatusTransition[];
  csatRating: number | null;
  createdAt: string;
  updatedAt: string;
  resolvedAt: string | null;
  userId: string;
}

type TicketStatus =
  | 'Acknowledge For Evaluation'
  | 'Resource Assignment'
  | 'Investigation Ongoing'
  | 'Resolution Ongoing'
  | 'For Documentation of RCA'
  | 'For User Acknowledgment'
  | 'CANCELLED TICKET'
  | 'AUTO CLOSE'
  | 'FOR SCHEDULE OF VISIT'
  | 'WAITING DEVELOPER RESPONSE';

type SmartTag = 'RECURRING' | 'ESCALATED';

interface StatusTransition {
  from: TicketStatus;
  to: TicketStatus;
  timestamp: string;
}
```

**Ticket ID Generation:**
```typescript
function generateTicketId(): string {
  const year = new Date().getFullYear();
  const seq = Math.floor(1000 + Math.random() * 9000);
  return `INC-${year}-${seq}`;
}
```

### 3. Smart Tagging Engine

Applies automatic tags based on recurrence and escalation logic.

```typescript
// src/server/services/taggingService.ts

interface TaggingContext {
  ticket: Ticket;
  recentTickets: Ticket[]; // tickets from last 7 days
}

function computeSmartTags(context: TaggingContext): SmartTag[] {
  const tags: SmartTag[] = [];

  // Recurring check: same system + same error within 7 days
  const hasRecurrence = context.recentTickets.some(
    (t) =>
      t.systemAffected === context.ticket.systemAffected &&
      t.errorDetails === context.ticket.errorDetails &&
      t.id !== context.ticket.id
  );
  if (hasRecurrence) tags.push('RECURRING');

  // Escalation check: high impact level
  if (
    context.ticket.impactLevel === 'Team' ||
    context.ticket.impactLevel === 'Entire Department'
  ) {
    tags.push('ESCALATED');
  }

  return tags;
}
```

### 4. Email Service (Mock)

Logs emails to console and persists them as records.

```typescript
// src/server/services/emailService.ts

interface EmailRecord {
  id: string;
  ticketId: string;
  type: EmailType;
  to: string;
  subject: string;
  body: string;
  sentAt: string;
}

type EmailType =
  | 'ACKNOWLEDGMENT'
  | 'STATUS_UPDATE'
  | 'SLA_BREACH'
  | 'REMINDER'
  | 'AUTO_CLOSE';

function sendEmail(email: Omit<EmailRecord, 'id' | 'sentAt'>): EmailRecord {
  const record: EmailRecord = {
    ...email,
    id: generateId(),
    sentAt: new Date().toISOString(),
  };
  console.log(`[EMAIL] To: ${record.to} | Subject: ${record.subject}`);
  console.log(`[EMAIL] Body: ${record.body}`);
  emailStore.set(record.id, record);
  return record;
}
```

### 5. SLA Monitoring Service

Background process that checks for SLA breaches and auto-close conditions.

```typescript
// src/server/services/slaService.ts

const SLA_BREACH_THRESHOLD_MS = 2 * 24 * 60 * 60 * 1000; // 2 days
const REMINDER_THRESHOLD_MS = 2 * 24 * 60 * 60 * 1000; // 2 days
const AUTO_CLOSE_THRESHOLD_MS = 3 * 24 * 60 * 60 * 1000; // 3 days

interface SlaCheckResult {
  ticketId: string;
  breached: boolean;
  daysInStatus: number;
  currentStatus: TicketStatus;
}

function checkSlaBreaches(tickets: Ticket[], now: Date): SlaCheckResult[] {
  return tickets
    .filter((t) => t.status !== 'For User Acknowledgment'
      && t.status !== 'AUTO CLOSE'
      && t.status !== 'CANCELLED TICKET')
    .map((t) => {
      const lastTransition = t.statusHistory[t.statusHistory.length - 1];
      const timeInStatus = now.getTime() - new Date(lastTransition.timestamp).getTime();
      return {
        ticketId: t.id,
        breached: timeInStatus > SLA_BREACH_THRESHOLD_MS,
        daysInStatus: timeInStatus / (24 * 60 * 60 * 1000),
        currentStatus: t.status,
      };
    });
}

function checkAutoClose(tickets: Ticket[], now: Date): string[] {
  return tickets
    .filter((t) => t.status === 'For User Acknowledgment')
    .filter((t) => {
      const lastTransition = t.statusHistory[t.statusHistory.length - 1];
      const timeInStatus = now.getTime() - new Date(lastTransition.timestamp).getTime();
      return timeInStatus > AUTO_CLOSE_THRESHOLD_MS;
    })
    .map((t) => t.id);
}
```

### 6. Performance Points Service

Calculates and tracks performance metrics.

```typescript
// src/server/services/pointsService.ts

interface PointsEvent {
  id: string;
  ticketId: string | null;
  eventType: PointsEventType;
  points: number;
  timestamp: string;
}

type PointsEventType =
  | 'FCR'
  | 'RESOLVED_WITHIN_EWT'
  | 'SLA_BREACH'
  | 'CSAT_5_STAR'
  | 'CSAT_4_STAR'
  | 'CSAT_LOW';

const POINTS_MAP: Record<PointsEventType, number> = {
  FCR: 15,
  RESOLVED_WITHIN_EWT: 10,
  SLA_BREACH: -10,
  CSAT_5_STAR: 10,
  CSAT_4_STAR: 5,
  CSAT_LOW: -5,
};

function calculateCsatPoints(rating: number): { eventType: PointsEventType; points: number } | null {
  if (rating === 5) return { eventType: 'CSAT_5_STAR', points: 10 };
  if (rating === 4) return { eventType: 'CSAT_4_STAR', points: 5 };
  if (rating <= 2) return { eventType: 'CSAT_LOW', points: -5 };
  return null; // rating 3 gives no points
}
```

### 7. Maintenance Window Store

```typescript
// src/server/services/maintenanceService.ts

interface MaintenanceWindow {
  id: string;
  system: SystemType;
  startTime: string; // ISO datetime
  endTime: string;   // ISO datetime
  description: string;
}

function isWithinMaintenanceWindow(
  system: SystemType,
  dateTime: string,
  windows: MaintenanceWindow[]
): MaintenanceWindow | null {
  const checkTime = new Date(dateTime).getTime();
  return windows.find(
    (w) =>
      w.system === system &&
      checkTime >= new Date(w.startTime).getTime() &&
      checkTime <= new Date(w.endTime).getTime()
  ) ?? null;
}
```

---

## Data Models

### In-Memory Store Structure

```typescript
// src/server/store/dataStore.ts

interface DataStore {
  wizardSessions: Map<string, WizardSession>;
  tickets: Map<string, Ticket>;
  emails: Map<string, EmailRecord>;
  maintenanceWindows: Map<string, MaintenanceWindow>;
  pointsEvents: PointsEvent[];
  ticketIdCounter: number;
}
```

### File Persistence Format

Data is persisted to `./data/store.json` on graceful shutdown and loaded on startup:

```typescript
interface PersistedData {
  tickets: Ticket[];
  emails: EmailRecord[];
  maintenanceWindows: MaintenanceWindow[];
  pointsEvents: PointsEvent[];
  ticketIdCounter: number;
}
```

---

## API Endpoints

### Wizard Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/wizard/start` | Start a new wizard session |
| POST | `/api/wizard/:sessionId/answer` | Submit answer for current step |
| GET | `/api/wizard/:sessionId` | Get current session state |

**POST /api/wizard/start**
```typescript
// Response
{
  sessionId: string;
  currentStep: 'ERROR_DETAILS';
  question: 'What is the specific error message or behavior you are experiencing?';
}
```

**POST /api/wizard/:sessionId/answer**
```typescript
// Request
{ answer: string }

// Response (varies by step)
{
  sessionId: string;
  currentStep: WizardStep;
  question?: string;
  options?: string[];
  solutions?: string[];
  maintenanceInfo?: MaintenanceInfo;
  ticketId?: string; // only when ticket is created
}
```

### Ticket Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/tickets` | List all tickets |
| GET | `/api/tickets/:id` | Get ticket details |
| PATCH | `/api/tickets/:id/status` | Update ticket status |
| POST | `/api/tickets/:id/csat` | Submit CSAT rating |

**PATCH /api/tickets/:id/status**
```typescript
// Request
{ status: TicketStatus }

// Response
{
  ticket: Ticket;
  emailSent: EmailRecord;
}
```

**POST /api/tickets/:id/csat**
```typescript
// Request
{ rating: number } // 1-5

// Response
{
  ticket: Ticket;
  pointsAwarded: number | null;
}
```

### Email Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/emails` | List all email records |
| GET | `/api/emails?ticketId=:id` | Get emails for a ticket |

### Admin / Points Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/points` | Get total performance points |
| GET | `/api/points/events` | List all points events |
| GET | `/api/maintenance-windows` | List maintenance windows |
| POST | `/api/maintenance-windows` | Create a maintenance window |

### SLA Check Endpoint (Manual Trigger)

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/admin/sla-check` | Manually trigger SLA check |
| POST | `/api/admin/auto-close-check` | Manually trigger auto-close check |

---

## EWT Configuration

```typescript
const EWT_HOURS: Record<SystemType, number> = {
  'Network': 4,
  'Email': 2,
  'ERP': 6,
  'VPN': 3,
  'Other Corporate Tools': 8,
};
```

---

## Error Handling

### Input Validation

All API endpoints validate inputs before processing:

```typescript
// Validation middleware pattern
function validateWizardAnswer(step: WizardStep, answer: string): ValidationResult {
  switch (step) {
    case WizardStep.ERROR_DETAILS:
      return answer.trim().length > 0
        ? { valid: true }
        : { valid: false, error: 'Error details cannot be empty' };
    case WizardStep.SYSTEM_AFFECTED:
      return VALID_SYSTEMS.includes(answer as SystemType)
        ? { valid: true }
        : { valid: false, error: `Invalid system. Must be one of: ${VALID_SYSTEMS.join(', ')}` };
    case WizardStep.DATE_TIME:
      return !isNaN(Date.parse(answer))
        ? { valid: true }
        : { valid: false, error: 'Invalid date/time format' };
    case WizardStep.IMPACT_LEVEL:
      return VALID_IMPACTS.includes(answer as ImpactLevel)
        ? { valid: true }
        : { valid: false, error: `Invalid impact level. Must be one of: ${VALID_IMPACTS.join(', ')}` };
    default:
      return { valid: false, error: 'Unexpected step' };
  }
}
```

### Error Response Format

```typescript
interface ApiError {
  error: string;
  code: string;
  details?: string;
}
```

HTTP Status codes:
- `400` — Invalid input or validation failure
- `404` — Resource not found (ticket, session)
- `409` — Invalid state transition
- `500` — Internal server error

### Status Transition Validation

Not all status transitions are valid. The system enforces a transition map:

```typescript
const VALID_TRANSITIONS: Record<TicketStatus, TicketStatus[]> = {
  'Acknowledge For Evaluation': ['Resource Assignment', 'CANCELLED TICKET', 'FOR SCHEDULE OF VISIT'],
  'Resource Assignment': ['Investigation Ongoing', 'CANCELLED TICKET'],
  'Investigation Ongoing': ['Resolution Ongoing', 'WAITING DEVELOPER RESPONSE', 'CANCELLED TICKET'],
  'Resolution Ongoing': ['For Documentation of RCA', 'CANCELLED TICKET'],
  'For Documentation of RCA': ['For User Acknowledgment', 'CANCELLED TICKET'],
  'For User Acknowledgment': ['AUTO CLOSE', 'CANCELLED TICKET'],
  'CANCELLED TICKET': [],
  'AUTO CLOSE': [],
  'FOR SCHEDULE OF VISIT': ['Investigation Ongoing', 'CANCELLED TICKET'],
  'WAITING DEVELOPER RESPONSE': ['Investigation Ongoing', 'Resolution Ongoing', 'CANCELLED TICKET'],
};
```

---

## Project Structure

```
/
├── src/
│   ├── server/
│   │   ├── index.ts                  # Express app entry point
│   │   ├── routes/
│   │   │   ├── wizardRoutes.ts
│   │   │   ├── ticketRoutes.ts
│   │   │   ├── emailRoutes.ts
│   │   │   ├── pointsRoutes.ts
│   │   │   └── adminRoutes.ts
│   │   ├── services/
│   │   │   ├── wizardService.ts
│   │   │   ├── ticketService.ts
│   │   │   ├── taggingService.ts
│   │   │   ├── emailService.ts
│   │   │   ├── slaService.ts
│   │   │   ├── pointsService.ts
│   │   │   └── maintenanceService.ts
│   │   ├── store/
│   │   │   └── dataStore.ts
│   │   ├── models/
│   │   │   └── types.ts
│   │   └── middleware/
│   │       └── validation.ts
│   └── client/
│       ├── index.html
│       ├── main.tsx
│       ├── App.tsx
│       ├── components/
│       │   ├── Wizard/
│       │   │   ├── WizardFlow.tsx
│       │   │   └── WizardStep.tsx
│       │   ├── Tickets/
│       │   │   ├── TicketList.tsx
│       │   │   └── TicketDetail.tsx
│       │   ├── CSAT/
│       │   │   └── CsatSurvey.tsx
│       │   └── Admin/
│       │       └── AdminPanel.tsx
│       └── services/
│           └── api.ts
├── data/
│   └── store.json
├── tests/
│   ├── unit/
│   │   ├── wizardService.test.ts
│   │   ├── ticketService.test.ts
│   │   ├── taggingService.test.ts
│   │   ├── slaService.test.ts
│   │   └── pointsService.test.ts
│   └── property/
│       ├── wizard.property.test.ts
│       ├── ticket.property.test.ts
│       ├── tagging.property.test.ts
│       ├── sla.property.test.ts
│       └── points.property.test.ts
├── package.json
├── tsconfig.json
├── vite.config.ts
└── vitest.config.ts
```

---

## Implementation Approach

### Phase 1: Foundation
1. Initialize project with package.json, TypeScript config, and build tooling
2. Set up Express server with basic routing structure
3. Implement in-memory data store with file persistence
4. Define shared type definitions

### Phase 2: Core Business Logic
1. Implement Wizard Service with state machine logic
2. Implement Ticket Service with ID generation and CRUD
3. Implement Smart Tagging Engine
4. Implement Maintenance Window service

### Phase 3: Notifications & SLA
1. Implement Email Service (mock with console logging)
2. Implement EWT calculation
3. Implement SLA breach detection logic
4. Implement auto-close and reminder logic

### Phase 4: Scoring & Frontend
1. Implement Performance Points calculation
2. Implement CSAT survey logic
3. Build React frontend with Wizard, Ticket, and Admin views
4. Wire up API calls from frontend to backend

---

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Wizard state machine follows deterministic transitions

*For any* valid wizard session and any valid answer to the current step, the wizard SHALL advance to exactly one deterministic next step: ERROR_DETAILS → SYSTEM_AFFECTED → DATE_TIME → IMPACT_LEVEL → SOLUTIONS → RESOLUTION_CHECK, with no skipped or out-of-order transitions.

**Validates: Requirements 1.2, 1.3, 1.4**

### Property 2: Maintenance window halts wizard when date overlaps

*For any* system type and date/time value that falls within a scheduled maintenance window for that system, the wizard SHALL halt the flow and return maintenance information including the downtime duration and scheduled uptime.

**Validates: Requirements 2.1, 2.2**

### Property 3: Ticket creation preserves all wizard data

*For any* completed wizard session where the user indicates the issue is not resolved, the created ticket SHALL contain all four diagnostic responses (errorDetails, systemAffected, dateTime, impactLevel), have a unique ID matching the format INC-YYYY-NNNN, and have initial status "Acknowledge For Evaluation".

**Validates: Requirements 3.1, 3.2, 3.3**

### Property 4: Recurring tag applied for duplicate issues within 7 days

*For any* ticket being created, if there exists another ticket with identical systemAffected and errorDetails fields that was created within the preceding 7 days, the new ticket SHALL have the [RECURRING] smart tag applied.

**Validates: Requirements 4.1**

### Property 5: Escalated tag applied for high-impact tickets

*For any* ticket with an impactLevel of "Team" or "Entire Department", the ticket SHALL have the [ESCALATED] smart tag applied.

**Validates: Requirements 4.2**

### Property 6: EWT mapping produces correct hours for all system types

*For any* valid system type, the acknowledgment email SHALL include an EWT value that matches the defined mapping: Network=4h, Email=2h, ERP=6h, VPN=3h, Other Corporate Tools=8h.

**Validates: Requirements 5.1, 5.2, 5.3**

### Property 7: All emails are logged and persisted

*For any* email-triggering event (ticket creation, status change, SLA breach, reminder, auto-close), the system SHALL produce an email record that is both logged to console output and stored in the email data store.

**Validates: Requirements 5.4, 6.3**

### Property 8: Status transitions record history with timestamps

*For any* valid ticket status change, the system SHALL append a StatusTransition record containing the previous status, new status, and a valid ISO timestamp to the ticket's statusHistory array.

**Validates: Requirements 6.2**

### Property 9: SLA breach detection at 2-day threshold

*For any* ticket in a non-terminal status (excluding "For User Acknowledgment", "AUTO CLOSE", "CANCELLED TICKET"), if the time elapsed since the last status transition exceeds 2 days, the system SHALL detect an SLA breach condition and generate a notification with a revised EWT greater than the original.

**Validates: Requirements 7.1, 7.2, 7.3**

### Property 10: Auto-close lifecycle for unacknowledged tickets

*For any* ticket in "For User Acknowledgment" status, if 2 days pass without user response a reminder email SHALL be sent, and if 3 days pass without response the ticket status SHALL change to "AUTO CLOSE" with a final notification email.

**Validates: Requirements 8.1, 8.2, 8.3**

### Property 11: CSAT rating persistence

*For any* valid CSAT rating (integer 1–5) submitted for a ticket in "For User Acknowledgment" status, the rating SHALL be stored and associated with the corresponding ticket.

**Validates: Requirements 9.2**

### Property 12: Performance points mapping is correct for all events

*For any* scoring event, the system SHALL award or deduct points according to the fixed mapping: FCR=+15, resolved within EWT=+10, SLA breach=-10, 5-star CSAT=+10, 4-star CSAT=+5, 1-or-2-star CSAT=-5, 3-star CSAT=0.

**Validates: Requirements 10.1, 10.2, 10.3, 10.4, 10.5, 10.6**

### Property 13: Ticket status validation rejects invalid transitions

*For any* ticket with a current status S and a requested new status T, if T is not in the set of valid transitions for S, the system SHALL reject the transition and leave the ticket unchanged.

**Validates: Requirements 6.1**
