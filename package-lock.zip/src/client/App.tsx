import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import WizardFlow from './components/Wizard/WizardFlow';
import TicketList from './components/Tickets/TicketList';
import TicketDetail from './components/Tickets/TicketDetail';
import AdminPanel from './components/Admin/AdminPanel';

function App() {
  return (
    <BrowserRouter>
      <div style={{ fontFamily: 'system-ui, -apple-system, sans-serif', maxWidth: '1200px', margin: '0 auto', padding: '20px' }}>
        <header style={{ borderBottom: '2px solid #2563eb', paddingBottom: '16px', marginBottom: '24px' }}>
          <h1 style={{ color: '#1e40af', margin: 0 }}>IT Self-Help &amp; Smart Ticketing</h1>
          <nav style={{ marginTop: '12px', display: 'flex', gap: '16px' }}>
            <Link to="/" style={{ color: '#2563eb', textDecoration: 'none', fontWeight: 500 }}>Self-Help Wizard</Link>
            <Link to="/tickets" style={{ color: '#2563eb', textDecoration: 'none', fontWeight: 500 }}>Tickets</Link>
            <Link to="/admin" style={{ color: '#2563eb', textDecoration: 'none', fontWeight: 500 }}>Admin Panel</Link>
          </nav>
        </header>

        <main>
          <Routes>
            <Route path="/" element={<WizardFlow />} />
            <Route path="/tickets" element={<TicketList />} />
            <Route path="/tickets/:id" element={<TicketDetail />} />
            <Route path="/admin" element={<AdminPanel />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

export default App;
