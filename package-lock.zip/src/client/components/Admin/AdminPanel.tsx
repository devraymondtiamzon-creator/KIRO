import React, { useEffect, useState } from 'react';
import {
  getPoints,
  getPointsEvents,
  getEmails,
  getMaintenanceWindows,
  createMaintenanceWindow,
  triggerSlaCheck,
} from '../../services/api';

function AdminPanel() {
  const [totalPoints, setTotalPoints] = useState(0);
  const [pointsEvents, setPointsEvents] = useState<any[]>([]);
  const [emails, setEmails] = useState<any[]>([]);
  const [maintenanceWindows, setMaintenanceWindows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [slaResult, setSlaResult] = useState<any>(null);

  // Maintenance window form
  const [mwForm, setMwForm] = useState({
    system: 'Network',
    startTime: '',
    endTime: '',
    description: '',
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [points, events, emailData, mwData] = await Promise.all([
        getPoints(),
        getPointsEvents(),
        getEmails(),
        getMaintenanceWindows(),
      ]);
      setTotalPoints(points.totalPoints);
      setPointsEvents(events);
      setEmails(emailData);
      setMaintenanceWindows(mwData);
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSlaCheck = async () => {
    try {
      const result = await triggerSlaCheck();
      setSlaResult(result);
      loadData(); // Refresh data
    } catch (err) {
      console.error('SLA check failed:', err);
    }
  };

  const handleCreateMw = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createMaintenanceWindow(mwForm);
      setMwForm({ system: 'Network', startTime: '', endTime: '', description: '' });
      loadData();
    } catch (err) {
      console.error('Failed to create maintenance window:', err);
    }
  };

  if (loading) return <p>Loading admin panel...</p>;

  return (
    <div>
      <h2>Admin Panel</h2>

      {/* Performance Points */}
      <section style={{ marginBottom: '32px', padding: '16px', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
        <h3 style={{ marginTop: 0 }}>Performance Points</h3>
        <div style={{ fontSize: '36px', fontWeight: 700, color: totalPoints >= 0 ? '#16a34a' : '#dc2626' }}>
          {totalPoints > 0 ? '+' : ''}{totalPoints} pts
        </div>
        {pointsEvents.length > 0 && (
          <div style={{ marginTop: '16px' }}>
            <h4>Recent Events</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', maxHeight: '200px', overflow: 'auto' }}>
              {pointsEvents.slice(-10).reverse().map((event: any) => (
                <div key={event.id} style={{ fontSize: '13px', padding: '6px 8px', background: '#f9fafb', borderRadius: '4px' }}>
                  <span style={{ color: event.points > 0 ? '#16a34a' : '#dc2626', fontWeight: 600 }}>
                    {event.points > 0 ? '+' : ''}{event.points}
                  </span>
                  {' '}
                  <span>{event.eventType}</span>
                  {event.ticketId && <span style={{ color: '#6b7280' }}> ({event.ticketId})</span>}
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* SLA Check */}
      <section style={{ marginBottom: '32px', padding: '16px', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
        <h3 style={{ marginTop: 0 }}>SLA Management</h3>
        <button
          onClick={handleSlaCheck}
          style={{
            background: '#f59e0b',
            color: 'white',
            border: 'none',
            padding: '8px 16px',
            borderRadius: '6px',
            cursor: 'pointer',
          }}
        >
          Run SLA Check Now
        </button>
        {slaResult && (
          <div style={{ marginTop: '12px', fontSize: '13px', padding: '12px', background: '#f9fafb', borderRadius: '4px' }}>
            <p>Breaches found: {slaResult.breaches?.filter((b: any) => b.breached).length || 0}</p>
            <p>Reminders sent: {slaResult.reminders?.length || 0}</p>
            <p>Auto-closed: {slaResult.autoClosed?.length || 0}</p>
          </div>
        )}
      </section>

      {/* Maintenance Windows */}
      <section style={{ marginBottom: '32px', padding: '16px', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
        <h3 style={{ marginTop: 0 }}>Maintenance Windows</h3>

        <form onSubmit={handleCreateMw} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '16px' }}>
          <select
            value={mwForm.system}
            onChange={(e) => setMwForm({ ...mwForm, system: e.target.value })}
            style={{ padding: '8px', borderRadius: '4px', border: '1px solid #d1d5db' }}
          >
            <option value="Network">Network</option>
            <option value="Email">Email</option>
            <option value="ERP">ERP</option>
            <option value="VPN">VPN</option>
            <option value="Other Corporate Tools">Other Corporate Tools</option>
          </select>
          <input
            type="text"
            placeholder="Description"
            value={mwForm.description}
            onChange={(e) => setMwForm({ ...mwForm, description: e.target.value })}
            style={{ padding: '8px', borderRadius: '4px', border: '1px solid #d1d5db' }}
          />
          <input
            type="datetime-local"
            value={mwForm.startTime}
            onChange={(e) => setMwForm({ ...mwForm, startTime: e.target.value })}
            style={{ padding: '8px', borderRadius: '4px', border: '1px solid #d1d5db' }}
          />
          <input
            type="datetime-local"
            value={mwForm.endTime}
            onChange={(e) => setMwForm({ ...mwForm, endTime: e.target.value })}
            style={{ padding: '8px', borderRadius: '4px', border: '1px solid #d1d5db' }}
          />
          <button
            type="submit"
            style={{
              gridColumn: '1 / -1',
              background: '#2563eb',
              color: 'white',
              border: 'none',
              padding: '8px',
              borderRadius: '6px',
              cursor: 'pointer',
            }}
          >
            Add Maintenance Window
          </button>
        </form>

        {maintenanceWindows.length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {maintenanceWindows.map((mw: any) => (
              <div key={mw.id} style={{ fontSize: '13px', padding: '8px', background: '#f9fafb', borderRadius: '4px' }}>
                <strong>{mw.system}</strong> — {mw.description || 'No description'}
                <div style={{ color: '#6b7280', marginTop: '4px' }}>
                  {new Date(mw.startTime).toLocaleString()} → {new Date(mw.endTime).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ color: '#6b7280', fontSize: '14px' }}>No maintenance windows configured.</p>
        )}
      </section>

      {/* Email Log */}
      <section style={{ padding: '16px', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
        <h3 style={{ marginTop: 0 }}>Email Log ({emails.length} total)</h3>
        {emails.length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', maxHeight: '300px', overflow: 'auto' }}>
            {emails.slice(-20).reverse().map((email: any) => (
              <div key={email.id} style={{ fontSize: '13px', padding: '8px', background: '#f9fafb', borderRadius: '4px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <strong>{email.type}</strong>
                  <span style={{ color: '#6b7280' }}>{new Date(email.sentAt).toLocaleString()}</span>
                </div>
                <div style={{ color: '#4b5563', marginTop: '2px' }}>{email.subject}</div>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ color: '#6b7280', fontSize: '14px' }}>No emails sent yet.</p>
        )}
      </section>
    </div>
  );
}

export default AdminPanel;
