import React, { useState } from 'react';
import { startWizardSession, submitWizardAnswer } from '../../services/api';
import WizardStep from './WizardStep';

interface StepData {
  sessionId: string;
  currentStep: string;
  question?: string;
  options?: string[];
  solutions?: string[];
  maintenanceInfo?: {
    system: string;
    downtimeDuration: string;
    scheduledUptime: string;
    message: string;
  };
  ticketId?: string;
  resolved?: boolean;
  message?: string;
}

function WizardFlow() {
  const [stepData, setStepData] = useState<StepData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [started, setStarted] = useState(false);

  const handleStart = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await startWizardSession();
      setStepData(result);
      setStarted(true);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAnswer = async (answer: string) => {
    if (!stepData) return;
    setLoading(true);
    setError(null);
    try {
      const result = await submitWizardAnswer(stepData.sessionId, answer);
      setStepData(result);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setStepData(null);
    setStarted(false);
    setError(null);
  };

  if (!started) {
    return (
      <div style={{ textAlign: 'center', padding: '40px' }}>
        <h2>Welcome to the IT Self-Help Wizard</h2>
        <p style={{ color: '#6b7280', marginBottom: '24px' }}>
          Let me guide you through diagnosing your IT issue step by step.
        </p>
        <button
          onClick={handleStart}
          disabled={loading}
          style={{
            background: '#2563eb',
            color: 'white',
            border: 'none',
            padding: '12px 32px',
            borderRadius: '8px',
            fontSize: '16px',
            cursor: 'pointer',
          }}
        >
          {loading ? 'Starting...' : 'Start Diagnostic'}
        </button>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ padding: '20px', background: '#fef2f2', borderRadius: '8px', border: '1px solid #fecaca' }}>
        <p style={{ color: '#dc2626' }}>Error: {error}</p>
        <button onClick={handleReset} style={{ marginTop: '8px', padding: '8px 16px', cursor: 'pointer' }}>
          Start Over
        </button>
      </div>
    );
  }

  if (!stepData) return null;

  // Maintenance halt
  if (stepData.currentStep === 'MAINTENANCE_HALT' && stepData.maintenanceInfo) {
    return (
      <div style={{ padding: '20px', background: '#fefce8', borderRadius: '8px', border: '1px solid #fde047' }}>
        <h3 style={{ color: '#a16207' }}>Scheduled Maintenance Detected</h3>
        <p>{stepData.maintenanceInfo.message}</p>
        <p><strong>Downtime Duration:</strong> {stepData.maintenanceInfo.downtimeDuration}</p>
        <p><strong>Expected Uptime:</strong> {new Date(stepData.maintenanceInfo.scheduledUptime).toLocaleString()}</p>
        <button onClick={handleReset} style={{ marginTop: '12px', padding: '8px 16px', cursor: 'pointer' }}>
          Start Over
        </button>
      </div>
    );
  }

  // Completed
  if (stepData.currentStep === 'COMPLETED') {
    return (
      <div style={{ padding: '20px', background: stepData.resolved ? '#f0fdf4' : '#eff6ff', borderRadius: '8px', border: `1px solid ${stepData.resolved ? '#86efac' : '#93c5fd'}` }}>
        {stepData.resolved ? (
          <>
            <h3 style={{ color: '#16a34a' }}>Issue Resolved!</h3>
            <p>Great news! Your issue was resolved through self-help. No ticket needed.</p>
          </>
        ) : (
          <>
            <h3 style={{ color: '#2563eb' }}>Ticket Created</h3>
            <p>A support ticket has been created for your issue.</p>
            <p><strong>Ticket ID:</strong> <code style={{ background: '#e5e7eb', padding: '2px 8px', borderRadius: '4px' }}>{stepData.ticketId}</code></p>
            <p>You will receive email notifications as your ticket progresses.</p>
          </>
        )}
        <button onClick={handleReset} style={{ marginTop: '12px', padding: '8px 16px', cursor: 'pointer' }}>
          Start New Session
        </button>
      </div>
    );
  }

  // Active step
  return (
    <WizardStep
      stepData={stepData}
      onSubmit={handleAnswer}
      loading={loading}
    />
  );
}

export default WizardFlow;
