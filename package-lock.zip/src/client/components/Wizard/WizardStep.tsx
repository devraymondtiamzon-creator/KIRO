import React, { useState } from 'react';

interface StepData {
  sessionId: string;
  currentStep: string;
  question?: string;
  options?: string[];
  solutions?: string[];
}

interface WizardStepProps {
  stepData: StepData;
  onSubmit: (answer: string) => void;
  loading: boolean;
}

function WizardStep({ stepData, onSubmit, loading }: WizardStepProps) {
  const [input, setInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onSubmit(input.trim());
      setInput('');
    }
  };

  const handleOptionClick = (option: string) => {
    onSubmit(option);
    setInput('');
  };

  const stepLabels: Record<string, string> = {
    ERROR_DETAILS: 'Step 1 of 4',
    SYSTEM_AFFECTED: 'Step 2 of 4',
    DATE_TIME: 'Step 3 of 4',
    IMPACT_LEVEL: 'Step 4 of 4',
    RESOLUTION_CHECK: 'Self-Help Solutions',
  };

  return (
    <div style={{ maxWidth: '600px' }}>
      <div style={{ marginBottom: '8px', color: '#6b7280', fontSize: '14px' }}>
        {stepLabels[stepData.currentStep] || stepData.currentStep}
      </div>

      {stepData.solutions && stepData.solutions.length > 0 && (
        <div style={{ marginBottom: '16px', padding: '16px', background: '#f0fdf4', borderRadius: '8px', border: '1px solid #86efac' }}>
          <h4 style={{ margin: '0 0 12px 0', color: '#16a34a' }}>Try these solutions:</h4>
          <ol style={{ margin: 0, paddingLeft: '20px' }}>
            {stepData.solutions.map((solution, i) => (
              <li key={i} style={{ marginBottom: '8px' }}>{solution}</li>
            ))}
          </ol>
        </div>
      )}

      <h3 style={{ marginBottom: '16px' }}>{stepData.question}</h3>

      {stepData.options ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {stepData.options.map((option) => (
            <button
              key={option}
              onClick={() => handleOptionClick(option)}
              disabled={loading}
              style={{
                padding: '12px 16px',
                border: '1px solid #d1d5db',
                borderRadius: '8px',
                background: 'white',
                cursor: 'pointer',
                textAlign: 'left',
                fontSize: '14px',
                transition: 'border-color 0.2s',
              }}
              onMouseOver={(e) => (e.currentTarget.style.borderColor = '#2563eb')}
              onMouseOut={(e) => (e.currentTarget.style.borderColor = '#d1d5db')}
            >
              {option}
            </button>
          ))}
        </div>
      ) : (
        <form onSubmit={handleSubmit}>
          <input
            type={stepData.currentStep === 'DATE_TIME' ? 'datetime-local' : 'text'}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your answer..."
            disabled={loading}
            style={{
              width: '100%',
              padding: '12px',
              border: '1px solid #d1d5db',
              borderRadius: '8px',
              fontSize: '14px',
              boxSizing: 'border-box',
            }}
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            style={{
              marginTop: '12px',
              background: '#2563eb',
              color: 'white',
              border: 'none',
              padding: '10px 24px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '14px',
            }}
          >
            {loading ? 'Submitting...' : 'Next'}
          </button>
        </form>
      )}
    </div>
  );
}

export default WizardStep;
