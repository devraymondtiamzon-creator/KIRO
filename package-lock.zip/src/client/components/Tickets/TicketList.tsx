import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getTickets } from '../../services/api';

function TicketList() {
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadTickets();
  }, []);

  const loadTickets = async () => {
    try {
      const data = await getTickets();
      setTickets(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <p>Loading tickets...</p>;
  if (error) return <p style={{ color: '#dc2626' }}>Error: {error}</p>;

  if (tickets.length === 0) {
    return (
      <div style={{ textAlign: 'center', padding: '40px', color: '#6b7280' }}>
        <h2>No Tickets</h2>
        <p>No support tickets have been created yet. Use the Self-Help Wizard to report an issue.</p>
      </div>
    );
  }

  return (
    <div>
      <h2>Support Tickets</h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {tickets.map((ticket) => (
          <Link
            key={ticket.id}
            to={`/tickets/${ticket.id}`}
            style={{ textDecoration: 'none', color: 'inherit' }}
          >
            <div
              style={{
                padding: '16px',
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                background: 'white',
                transition: 'box-shadow 0.2s',
              }}
              onMouseOver={(e) => (e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)')}
              onMouseOut={(e) => (e.currentTarget.style.boxShadow = 'none')}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <strong style={{ fontSize: '16px' }}>{ticket.id}</strong>
                  <span style={{ marginLeft: '12px', color: '#6b7280' }}>{ticket.systemAffected}</span>
                </div>
                <span
                  style={{
                    padding: '4px 12px',
                    borderRadius: '12px',
                    fontSize: '12px',
                    fontWeight: 500,
                    background: getStatusColor(ticket.status),
                    color: 'white',
                  }}
                >
                  {ticket.status}
                </span>
              </div>
              <p style={{ margin: '8px 0 0', color: '#4b5563', fontSize: '14px' }}>
                {ticket.errorDetails.substring(0, 100)}{ticket.errorDetails.length > 100 ? '...' : ''}
              </p>
              <div style={{ marginTop: '8px', display: 'flex', gap: '8px' }}>
                {ticket.tags.map((tag: string) => (
                  <span
                    key={tag}
                    style={{
                      padding: '2px 8px',
                      borderRadius: '4px',
                      fontSize: '11px',
                      fontWeight: 600,
                      background: tag === 'ESCALATED' ? '#fef2f2' : '#fefce8',
                      color: tag === 'ESCALATED' ? '#dc2626' : '#a16207',
                      border: `1px solid ${tag === 'ESCALATED' ? '#fecaca' : '#fde047'}`,
                    }}
                  >
                    [{tag}]
                  </span>
                ))}
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    'Acknowledge For Evaluation': '#6366f1',
    'Resource Assignment': '#8b5cf6',
    'Investigation Ongoing': '#f59e0b',
    'Resolution Ongoing': '#3b82f6',
    'For Documentation of RCA': '#10b981',
    'For User Acknowledgment': '#22c55e',
    'CANCELLED TICKET': '#6b7280',
    'AUTO CLOSE': '#9ca3af',
    'FOR SCHEDULE OF VISIT': '#ec4899',
    'WAITING DEVELOPER RESPONSE': '#f97316',
  };
  return colors[status] || '#6b7280';
}

export default TicketList;
