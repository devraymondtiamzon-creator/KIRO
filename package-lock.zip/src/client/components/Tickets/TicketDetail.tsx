import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getTicket, updateTicketStatus, getEmails } from '../../services/api';
import CsatSurvey from '../CSAT/CsatSurvey';

const VALID_TRANSITIONS: Record<string, string[]> = {
  'Acknowledge For Evaluation': ['Resource Assignment', 'CANCELLED TICKET', 'FOR SCHEDULE OF VISIT'],
  'Resource Assignment': ['Investigation Ongoing', 'CANCELLED TICKET'],
  'Investigation Ongoing': ['Resolution Ongoing', 'WAITING DEVELOPER RESPONSE', 'CANCELLED TICKET'],
  'Resolution Ongoing': ['For Documentation of RCA', 'CANCELLED TICKET'],
  'For Documentation of RCA': ['For User Acknowledgment', 'CANCELLED TICKET'],
  'For User Acknowledgment': ['AUTO CLOSE', 'CANCELLED TICKET'],
  'CANCELLED TICKET': [],
  'AUTO CLOSE': [],
  'FOR SCHEDULE OF VISIT': ['Investigation Ongoing', 'CANCELLED TICKET'],
  'WAITING DEVELOPER RESPONSE': ['Investigation Ongoing', 'Resolution Ongoing', 'CANCELLED TICKET'],
};

function TicketDetail() {
  const { id } = useParams<{ id: string }>();
  const [ticket, setTicket] = useState<any>(null);
  const [emails, setEmails] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    if (id) loadData();
  }, [id]);

  const loadData = async () => {
    try {
      const [ticketData, emailData] = await Promise.all([
        getTicket(id!),
        getEmails(id),
      ]);
      setTicket(ticketData);
      setEmails(emailData);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (newStatus: string) => {
    setUpdating(true);
    try {
      const updated = await updateTicketStatus(id!, newStatus);
      setTicket(updated);
      const emailData = await getEmails(id);
      setEmails(emailData);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setUpdating(false);
    }
  };

  if (loading) return <p>Loading ticket...</p>;
  if (error) return <p style={{ color: '#dc2626' }}>Error: {error}</p>;
  if (!ticket) return <p>Ticket not found</p>;

  const availableTransitions = VALID_TRANSITIONS[ticket.status] || [];

  return (
    <div>
      <h2>Ticket: {ticket.id}</h2>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
        {/* Ticket Info */}
        <div style={{ padding: '16px', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
          <h3 style={{ marginTop: 0 }}>Details</h3>
          <dl style={{ margin: 0 }}>
            <dt style={{ fontWeight: 600, color: '#6b7280', fontSize: '12px', marginTop: '12px' }}>System</dt>
            <dd style={{ margin: '4px 0 0' }}>{ticket.systemAffected}</dd>
            <dt style={{ fontWeight: 600, color: '#6b7280', fontSize: '12px', marginTop: '12px' }}>Error</dt>
            <dd style={{ margin: '4px 0 0' }}>{ticket.errorDetails}</dd>
            <dt style={{ fontWeight: 600, color: '#6b7280', fontSize: '12px', marginTop: '12px' }}>Impact</dt>
            <dd style={{ margin: '4px 0 0' }}>{ticket.impactLevel}</dd>
            <dt style={{ fontWeight: 600, color: '#6b7280', fontSize: '12px', marginTop: '12px' }}>Status</dt>
            <dd style={{ margin: '4px 0 0', fontWeight: 600 }}>{ticket.status}</dd>
            <dt style={{ fontWeight: 600, color: '#6b7280', fontSize: '12px', marginTop: '12px' }}>EWT</dt>
            <dd style={{ margin: '4px 0 0' }}>{ticket.ewt} hours</dd>
            <dt style={{ fontWeight: 600, color: '#6b7280', fontSize: '12px', marginTop: '12px' }}>Tags</dt>
            <dd style={{ margin: '4px 0 0' }}>
              {ticket.tags.length > 0
                ? ticket.tags.map((t: string) => `[${t}]`).join(' ')
                : 'None'}
            </dd>
            <dt style={{ fontWeight: 600, color: '#6b7280', fontSize: '12px', marginTop: '12px' }}>Created</dt>
            <dd style={{ margin: '4px 0 0' }}>{new Date(ticket.createdAt).toLocaleString()}</dd>
            {ticket.csatRating && (
              <>
                <dt style={{ fontWeight: 600, color: '#6b7280', fontSize: '12px', marginTop: '12px' }}>CSAT Rating</dt>
                <dd style={{ margin: '4px 0 0' }}>{'⭐'.repeat(ticket.csatRating)} ({ticket.csatRating}/5)</dd>
              </>
            )}
          </dl>
        </div>

        {/* Status Actions */}
        <div>
          {availableTransitions.length > 0 && (
            <div style={{ padding: '16px', border: '1px solid #e5e7eb', borderRadius: '8px', marginBottom: '16px' }}>
              <h3 style={{ marginTop: 0 }}>Update Status</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {availableTransitions.map((status) => (
                  <button
                    key={status}
                    onClick={() => handleStatusUpdate(status)}
                    disabled={updating}
                    style={{
                      padding: '8px 16px',
                      border: '1px solid #d1d5db',
                      borderRadius: '6px',
                      background: 'white',
                      cursor: 'pointer',
                      textAlign: 'left',
                      fontSize: '13px',
                    }}
                  >
                    → {status}
                  </button>
                ))}
              </div>
            </div>
          )}

          {ticket.status === 'For User Acknowledgment' && !ticket.csatRating && (
            <CsatSurvey ticketId={ticket.id} onSubmit={loadData} />
          )}
        </div>
      </div>

      {/* Status History */}
      <div style={{ marginTop: '24px', padding: '16px', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
        <h3 style={{ marginTop: 0 }}>Status History</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {ticket.statusHistory.map((h: any, i: number) => (
            <div key={i} style={{ fontSize: '13px', padding: '8px', background: '#f9fafb', borderRadius: '4px' }}>
              <span style={{ color: '#6b7280' }}>{new Date(h.timestamp).toLocaleString()}</span>
              {' — '}
              <span>{h.from}</span>
              {' → '}
              <strong>{h.to}</strong>
            </div>
          ))}
        </div>
      </div>

      {/* Email Log */}
      {emails.length > 0 && (
        <div style={{ marginTop: '24px', padding: '16px', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
          <h3 style={{ marginTop: 0 }}>Email Notifications</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {emails.map((email: any) => (
              <div key={email.id} style={{ fontSize: '13px', padding: '8px', background: '#f9fafb', borderRadius: '4px' }}>
                <div><strong>{email.type}</strong> — {email.subject}</div>
                <div style={{ color: '#6b7280', marginTop: '4px' }}>{new Date(email.sentAt).toLocaleString()}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default TicketDetail;
