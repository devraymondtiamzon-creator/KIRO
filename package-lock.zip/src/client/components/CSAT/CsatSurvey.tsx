import React, { useState } from 'react';
import { submitCsat } from '../../services/api';

interface CsatSurveyProps {
  ticketId: string;
  onSubmit: () => void;
}

function CsatSurvey({ ticketId, onSubmit }: CsatSurveyProps) {
  const [hoveredStar, setHoveredStar] = useState(0);
  const [selectedStar, setSelectedStar] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    if (selectedStar === 0) return;
    setSubmitting(true);
    try {
      await submitCsat(ticketId, selectedStar);
      setSubmitted(true);
      onSubmit();
    } catch (err) {
      console.error('Failed to submit CSAT:', err);
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div style={{ padding: '16px', background: '#f0fdf4', borderRadius: '8px', border: '1px solid #86efac' }}>
        <p style={{ margin: 0, color: '#16a34a', fontWeight: 500 }}>
          Thank you for your feedback! {'⭐'.repeat(selectedStar)}
        </p>
      </div>
    );
  }

  return (
    <div style={{ padding: '16px', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
      <h3 style={{ marginTop: 0 }}>How did we do?</h3>
      <p style={{ color: '#6b7280', fontSize: '14px' }}>Please rate your experience:</p>

      <div style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            onMouseEnter={() => setHoveredStar(star)}
            onMouseLeave={() => setHoveredStar(0)}
            onClick={() => setSelectedStar(star)}
            style={{
              fontSize: '32px',
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              opacity: star <= (hoveredStar || selectedStar) ? 1 : 0.3,
              transform: star <= (hoveredStar || selectedStar) ? 'scale(1.1)' : 'scale(1)',
              transition: 'all 0.15s',
            }}
            aria-label={`${star} star${star > 1 ? 's' : ''}`}
          >
            ⭐
          </button>
        ))}
      </div>

      {selectedStar > 0 && (
        <div>
          <p style={{ fontSize: '14px', color: '#6b7280' }}>
            {selectedStar === 5 && 'Excellent! Glad we could help!'}
            {selectedStar === 4 && 'Great! Thanks for the positive feedback.'}
            {selectedStar === 3 && 'Thanks. We appreciate your honest feedback.'}
            {selectedStar === 2 && 'Sorry to hear that. We will work to improve.'}
            {selectedStar === 1 && 'We apologize for the experience. We will do better.'}
          </p>
          <button
            onClick={handleSubmit}
            disabled={submitting}
            style={{
              background: '#2563eb',
              color: 'white',
              border: 'none',
              padding: '8px 20px',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '14px',
            }}
          >
            {submitting ? 'Submitting...' : 'Submit Rating'}
          </button>
        </div>
      )}
    </div>
  );
}

export default CsatSurvey;
