const BASE_URL = '/api';

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${BASE_URL}${url}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(error.error || `HTTP ${response.status}`);
  }

  return response.json();
}

// ========== Wizard API ==========

export function startWizardSession() {
  return request<any>('/wizard/start', { method: 'POST' });
}

export function getWizardSession(sessionId: string) {
  return request<any>(`/wizard/${sessionId}`);
}

export function submitWizardAnswer(sessionId: string, answer: string) {
  return request<any>(`/wizard/${sessionId}/answer`, {
    method: 'POST',
    body: JSON.stringify({ answer }),
  });
}

// ========== Ticket API ==========

export function getTickets() {
  return request<any[]>('/tickets');
}

export function getTicket(id: string) {
  return request<any>(`/tickets/${id}`);
}

export function updateTicketStatus(id: string, status: string) {
  return request<any>(`/tickets/${id}/status`, {
    method: 'PATCH',
    body: JSON.stringify({ status }),
  });
}

export function submitCsat(id: string, rating: number) {
  return request<any>(`/tickets/${id}/csat`, {
    method: 'POST',
    body: JSON.stringify({ rating }),
  });
}

// ========== Email API ==========

export function getEmails(ticketId?: string) {
  const params = ticketId ? `?ticketId=${ticketId}` : '';
  return request<any[]>(`/emails${params}`);
}

// ========== Points API ==========

export function getPoints() {
  return request<{ totalPoints: number }>('/points');
}

export function getPointsEvents() {
  return request<any[]>('/points/events');
}

// ========== Admin API ==========

export function getMaintenanceWindows() {
  return request<any[]>('/maintenance-windows');
}

export function createMaintenanceWindow(data: {
  system: string;
  startTime: string;
  endTime: string;
  description: string;
}) {
  return request<any>('/maintenance-windows', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export function triggerSlaCheck() {
  return request<any>('/admin/sla-check', { method: 'POST' });
}

export function triggerAutoCloseCheck() {
  return request<any>('/admin/auto-close-check', { method: 'POST' });
}
