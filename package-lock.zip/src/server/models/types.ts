// ========== Enums & Type Aliases ==========

export enum WizardStep {
  ERROR_DETAILS = 'ERROR_DETAILS',
  SYSTEM_AFFECTED = 'SYSTEM_AFFECTED',
  DATE_TIME = 'DATE_TIME',
  IMPACT_LEVEL = 'IMPACT_LEVEL',
  SOLUTIONS = 'SOLUTIONS',
  RESOLUTION_CHECK = 'RESOLUTION_CHECK',
  MAINTENANCE_HALT = 'MAINTENANCE_HALT',
  COMPLETED = 'COMPLETED',
}

export type SystemType = 'Network' | 'Email' | 'ERP' | 'VPN' | 'Other Corporate Tools';

export type ImpactLevel = 'Single User' | 'Team' | 'Entire Department';

export type TicketStatus =
  | 'Acknowledge For Evaluation'
  | 'Resource Assignment'
  | 'Investigation Ongoing'
  | 'Resolution Ongoing'
  | 'For Documentation of RCA'
  | 'For User Acknowledgment'
  | 'CANCELLED TICKET'
  | 'AUTO CLOSE'
  | 'FOR SCHEDULE OF VISIT'
  | 'WAITING DEVELOPER RESPONSE';

export type SmartTag = 'RECURRING' | 'ESCALATED';

export type EmailType =
  | 'ACKNOWLEDGMENT'
  | 'STATUS_UPDATE'
  | 'SLA_BREACH'
  | 'REMINDER'
  | 'AUTO_CLOSE';

export type PointsEventType =
  | 'FCR'
  | 'RESOLVED_WITHIN_EWT'
  | 'SLA_BREACH'
  | 'CSAT_5_STAR'
  | 'CSAT_4_STAR'
  | 'CSAT_LOW';

// ========== Interfaces ==========

export interface WizardSession {
  id: string;
  currentStep: WizardStep;
  responses: {
    errorDetails?: string;
    systemAffected?: SystemType;
    dateTime?: string;
    impactLevel?: ImpactLevel;
  };
  solutions: string[];
  resolved: boolean | null;
  createdAt: string;
}

export interface StatusTransition {
  from: TicketStatus;
  to: TicketStatus;
  timestamp: string;
}

export interface Ticket {
  id: string;
  errorDetails: string;
  systemAffected: SystemType;
  dateTime: string;
  impactLevel: ImpactLevel;
  status: TicketStatus;
  tags: SmartTag[];
  ewt: number; // in hours
  statusHistory: StatusTransition[];
  csatRating: number | null;
  createdAt: string;
  updatedAt: string;
  resolvedAt: string | null;
  userId: string;
}

export interface EmailRecord {
  id: string;
  ticketId: string;
  type: EmailType;
  to: string;
  subject: string;
  body: string;
  sentAt: string;
}

export interface MaintenanceWindow {
  id: string;
  system: SystemType;
  startTime: string;
  endTime: string;
  description: string;
}

export interface MaintenanceInfo {
  system: SystemType;
  downtimeDuration: string;
  scheduledUptime: string;
  message: string;
}

export interface PointsEvent {
  id: string;
  ticketId: string | null;
  eventType: PointsEventType;
  points: number;
  timestamp: string;
}

export interface WizardStepResult {
  sessionId: string;
  currentStep: WizardStep;
  question?: string;
  options?: string[];
  solutions?: string[];
  maintenanceInfo?: MaintenanceInfo;
  ticketId?: string;
}

export interface ValidationResult {
  valid: boolean;
  error?: string;
}

export interface ApiError {
  error: string;
  code: string;
  details?: string;
}

// ========== Constants ==========

export const VALID_SYSTEMS: SystemType[] = [
  'Network',
  'Email',
  'ERP',
  'VPN',
  'Other Corporate Tools',
];

export const VALID_IMPACTS: ImpactLevel[] = [
  'Single User',
  'Team',
  'Entire Department',
];

export const EWT_HOURS: Record<SystemType, number> = {
  Network: 4,
  Email: 2,
  ERP: 6,
  VPN: 3,
  'Other Corporate Tools': 8,
};

export const POINTS_MAP: Record<PointsEventType, number> = {
  FCR: 15,
  RESOLVED_WITHIN_EWT: 10,
  SLA_BREACH: -10,
  CSAT_5_STAR: 10,
  CSAT_4_STAR: 5,
  CSAT_LOW: -5,
};

export const VALID_TRANSITIONS: Record<TicketStatus, TicketStatus[]> = {
  'Acknowledge For Evaluation': ['Resource Assignment', 'CANCELLED TICKET', 'FOR SCHEDULE OF VISIT'],
  'Resource Assignment': ['Investigation Ongoing', 'CANCELLED TICKET'],
  'Investigation Ongoing': ['Resolution Ongoing', 'WAITING DEVELOPER RESPONSE', 'CANCELLED TICKET'],
  'Resolution Ongoing': ['For Documentation of RCA', 'CANCELLED TICKET'],
  'For Documentation of RCA': ['For User Acknowledgment', 'CANCELLED TICKET'],
  'For User Acknowledgment': ['AUTO CLOSE', 'CANCELLED TICKET'],
  'CANCELLED TICKET': [],
  'AUTO CLOSE': [],
  'FOR SCHEDULE OF VISIT': ['Investigation Ongoing', 'CANCELLED TICKET'],
  'WAITING DEVELOPER RESPONSE': ['Investigation Ongoing', 'Resolution Ongoing', 'CANCELLED TICKET'],
};

export const ALL_TICKET_STATUSES: TicketStatus[] = [
  'Acknowledge For Evaluation',
  'Resource Assignment',
  'Investigation Ongoing',
  'Resolution Ongoing',
  'For Documentation of RCA',
  'For User Acknowledgment',
  'CANCELLED TICKET',
  'AUTO CLOSE',
  'FOR SCHEDULE OF VISIT',
  'WAITING DEVELOPER RESPONSE',
];
