import { Router } from 'express';
import { getTicket, getAllTickets, updateTicketStatus, submitCsatRating } from '../services/ticketService.js';
import { validateStatusTransition, validateCsatRating } from '../middleware/validation.js';
import type { TicketStatus } from '../models/types.js';
import { ALL_TICKET_STATUSES } from '../models/types.js';

const router = Router();

/**
 * GET /api/tickets
 * List all tickets.
 */
router.get('/', (req, res) => {
  const tickets = getAllTickets();
  res.json(tickets);
});

/**
 * GET /api/tickets/:id
 * Get a single ticket by ID.
 */
router.get('/:id', (req, res) => {
  const ticket = getTicket(req.params.id);
  if (!ticket) {
    return res.status(404).json({
      error: 'Ticket not found',
      code: 'TICKET_NOT_FOUND',
    });
  }
  res.json(ticket);
});

/**
 * PATCH /api/tickets/:id/status
 * Update a ticket's status.
 */
router.patch('/:id/status', (req, res) => {
  const { status } = req.body;

  if (!status || !ALL_TICKET_STATUSES.includes(status as TicketStatus)) {
    return res.status(400).json({
      error: `Invalid status. Must be one of: ${ALL_TICKET_STATUSES.join(', ')}`,
      code: 'INVALID_INPUT',
    });
  }

  const ticket = getTicket(req.params.id);
  if (!ticket) {
    return res.status(404).json({
      error: 'Ticket not found',
      code: 'TICKET_NOT_FOUND',
    });
  }

  // Validate transition
  const validation = validateStatusTransition(ticket.status, status as TicketStatus);
  if (!validation.valid) {
    return res.status(409).json({
      error: validation.error,
      code: 'INVALID_TRANSITION',
    });
  }

  try {
    const updated = updateTicketStatus(req.params.id, status as TicketStatus);
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message, code: 'INTERNAL_ERROR' });
  }
});

/**
 * POST /api/tickets/:id/csat
 * Submit a CSAT rating for a ticket.
 */
router.post('/:id/csat', (req, res) => {
  const { rating } = req.body;

  const validation = validateCsatRating(rating);
  if (!validation.valid) {
    return res.status(400).json({
      error: validation.error,
      code: 'INVALID_INPUT',
    });
  }

  const ticket = getTicket(req.params.id);
  if (!ticket) {
    return res.status(404).json({
      error: 'Ticket not found',
      code: 'TICKET_NOT_FOUND',
    });
  }

  try {
    const updated = submitCsatRating(req.params.id, rating);
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message, code: 'INTERNAL_ERROR' });
  }
});

export default router;
