import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { dataStore } from '../store/dataStore.js';
import { runSlaChecks } from '../services/slaService.js';
import type { MaintenanceWindow, SystemType } from '../models/types.js';
import { VALID_SYSTEMS } from '../models/types.js';

const router = Router();

/**
 * GET /api/maintenance-windows
 * List all maintenance windows.
 */
router.get('/maintenance-windows', (req, res) => {
  res.json(dataStore.getMaintenanceWindows());
});

/**
 * POST /api/maintenance-windows
 * Create a new maintenance window.
 */
router.post('/maintenance-windows', (req, res) => {
  const { system, startTime, endTime, description } = req.body;

  if (!system || !VALID_SYSTEMS.includes(system as SystemType)) {
    return res.status(400).json({
      error: `Invalid system. Must be one of: ${VALID_SYSTEMS.join(', ')}`,
      code: 'INVALID_INPUT',
    });
  }

  if (!startTime || !endTime || isNaN(Date.parse(startTime)) || isNaN(Date.parse(endTime))) {
    return res.status(400).json({
      error: 'startTime and endTime must be valid ISO date strings',
      code: 'INVALID_INPUT',
    });
  }

  if (new Date(endTime).getTime() <= new Date(startTime).getTime()) {
    return res.status(400).json({
      error: 'endTime must be after startTime',
      code: 'INVALID_INPUT',
    });
  }

  const mw: MaintenanceWindow = {
    id: uuidv4(),
    system: system as SystemType,
    startTime,
    endTime,
    description: description || '',
  };

  dataStore.setMaintenanceWindow(mw);
  res.status(201).json(mw);
});

/**
 * POST /api/admin/sla-check
 * Manually trigger an SLA breach check.
 */
router.post('/sla-check', (req, res) => {
  const results = runSlaChecks();
  res.json(results);
});

/**
 * POST /api/admin/auto-close-check
 * Manually trigger auto-close check (same as sla-check but for clarity).
 */
router.post('/auto-close-check', (req, res) => {
  const results = runSlaChecks();
  res.json({
    reminders: results.reminders,
    autoClosed: results.autoClosed,
  });
});

export default router;
