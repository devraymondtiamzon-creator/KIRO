import { Router } from 'express';
import { dataStore } from '../store/dataStore.js';

const router = Router();

/**
 * GET /api/emails
 * List all email records. Optionally filter by ticketId query param.
 */
router.get('/', (req, res) => {
  const { ticketId } = req.query;

  if (ticketId && typeof ticketId === 'string') {
    const emails = dataStore.getEmailsByTicketId(ticketId);
    return res.json(emails);
  }

  res.json(dataStore.getEmails());
});

export default router;
