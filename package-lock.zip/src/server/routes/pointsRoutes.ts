import { Router } from 'express';
import { getTotalPoints, getPointsEvents } from '../services/pointsService.js';

const router = Router();

/**
 * GET /api/points
 * Get total accumulated performance points.
 */
router.get('/', (req, res) => {
  const total = getTotalPoints();
  res.json({ totalPoints: total });
});

/**
 * GET /api/points/events
 * List all points events.
 */
router.get('/events', (req, res) => {
  const events = getPointsEvents();
  res.json(events);
});

export default router;
