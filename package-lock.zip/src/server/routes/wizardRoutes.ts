import { Router } from 'express';
import { startSession, advanceStep, getSession } from '../services/wizardService.js';
import { createTicket } from '../services/ticketService.js';
import { awardPoints } from '../services/pointsService.js';
import { validateWizardAnswer } from '../middleware/validation.js';
import { WizardStep } from '../models/types.js';

const router = Router();

/**
 * POST /api/wizard/start
 * Start a new wizard session.
 */
router.post('/start', (req, res) => {
  try {
    const result = startSession();
    res.status(201).json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message, code: 'INTERNAL_ERROR' });
  }
});

/**
 * GET /api/wizard/:sessionId
 * Get current session state.
 */
router.get('/:sessionId', (req, res) => {
  const session = getSession(req.params.sessionId);
  if (!session) {
    return res.status(404).json({
      error: 'Session not found',
      code: 'SESSION_NOT_FOUND',
    });
  }
  res.json(session);
});

/**
 * POST /api/wizard/:sessionId/answer
 * Submit an answer for the current wizard step.
 */
router.post('/:sessionId/answer', (req, res) => {
  const { sessionId } = req.params;
  const { answer } = req.body;

  if (!answer || typeof answer !== 'string') {
    return res.status(400).json({
      error: 'Answer is required and must be a string',
      code: 'INVALID_INPUT',
    });
  }

  const session = getSession(sessionId);
  if (!session) {
    return res.status(404).json({
      error: 'Session not found',
      code: 'SESSION_NOT_FOUND',
    });
  }

  // Validate the answer against the current step
  const validation = validateWizardAnswer(session.currentStep, answer);
  if (!validation.valid) {
    return res.status(400).json({
      error: validation.error,
      code: 'VALIDATION_ERROR',
    });
  }

  try {
    const result = advanceStep(sessionId, answer);

    // If wizard completed and issue not resolved, create ticket
    if (result.currentStep === WizardStep.COMPLETED) {
      const updatedSession = getSession(sessionId)!;
      if (updatedSession.resolved) {
        // First Contact Resolution
        awardPoints(null, 'FCR');
        return res.json({ ...result, resolved: true, message: 'Issue resolved via self-help!' });
      } else {
        // Create ticket
        const ticket = createTicket(updatedSession);
        return res.json({ ...result, resolved: false, ticketId: ticket.id, ticket });
      }
    }

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message, code: 'INTERNAL_ERROR' });
  }
});

export default router;
