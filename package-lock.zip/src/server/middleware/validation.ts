import type { ValidationResult, TicketStatus } from '../models/types.js';
import { WizardStep, VALID_SYSTEMS, VALID_IMPACTS, VALID_TRANSITIONS } from '../models/types.js';
import type { SystemType, ImpactLevel } from '../models/types.js';

/**
 * Validates a wizard answer based on the current step.
 */
export function validateWizardAnswer(step: WizardStep, answer: string): ValidationResult {
  switch (step) {
    case WizardStep.ERROR_DETAILS:
      return answer.trim().length > 0
        ? { valid: true }
        : { valid: false, error: 'Error details cannot be empty' };

    case WizardStep.SYSTEM_AFFECTED:
      return VALID_SYSTEMS.includes(answer as SystemType)
        ? { valid: true }
        : { valid: false, error: `Invalid system. Must be one of: ${VALID_SYSTEMS.join(', ')}` };

    case WizardStep.DATE_TIME:
      return !isNaN(Date.parse(answer))
        ? { valid: true }
        : { valid: false, error: 'Invalid date/time format. Please provide a valid date.' };

    case WizardStep.IMPACT_LEVEL:
      return VALID_IMPACTS.includes(answer as ImpactLevel)
        ? { valid: true }
        : { valid: false, error: `Invalid impact level. Must be one of: ${VALID_IMPACTS.join(', ')}` };

    case WizardStep.RESOLUTION_CHECK:
      return ['yes', 'no'].includes(answer.toLowerCase())
        ? { valid: true }
        : { valid: false, error: 'Please answer with "Yes" or "No"' };

    default:
      return { valid: false, error: `Cannot accept answer at step: ${step}` };
  }
}

/**
 * Validates a ticket status transition.
 */
export function validateStatusTransition(
  currentStatus: TicketStatus,
  newStatus: TicketStatus
): ValidationResult {
  const allowed = VALID_TRANSITIONS[currentStatus];
  if (!allowed) {
    return { valid: false, error: `Unknown current status: ${currentStatus}` };
  }

  if (!allowed.includes(newStatus)) {
    return {
      valid: false,
      error: `Invalid transition from "${currentStatus}" to "${newStatus}". Allowed: ${allowed.join(', ')}`,
    };
  }

  return { valid: true };
}

/**
 * Validates a CSAT rating value.
 */
export function validateCsatRating(rating: unknown): ValidationResult {
  if (typeof rating !== 'number') {
    return { valid: false, error: 'Rating must be a number' };
  }

  if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
    return { valid: false, error: 'Rating must be an integer between 1 and 5' };
  }

  return { valid: true };
}
