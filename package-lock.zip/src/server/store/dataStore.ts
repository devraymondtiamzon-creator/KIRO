import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import type {
  WizardSession,
  Ticket,
  EmailRecord,
  MaintenanceWindow,
  PointsEvent,
} from '../models/types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_FILE = path.resolve(__dirname, '../../../data/store.json');

interface PersistedData {
  tickets: Ticket[];
  emails: EmailRecord[];
  maintenanceWindows: MaintenanceWindow[];
  pointsEvents: PointsEvent[];
  ticketIdCounter: number;
}

class DataStore {
  wizardSessions: Map<string, WizardSession> = new Map();
  tickets: Map<string, Ticket> = new Map();
  emails: Map<string, EmailRecord> = new Map();
  maintenanceWindows: Map<string, MaintenanceWindow> = new Map();
  pointsEvents: PointsEvent[] = [];
  ticketIdCounter: number = 1000;

  constructor() {
    this.loadFromFile();
  }

  // ========== Persistence ==========

  loadFromFile(): void {
    try {
      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        const data: PersistedData = JSON.parse(raw);

        for (const ticket of data.tickets) {
          this.tickets.set(ticket.id, ticket);
        }
        for (const email of data.emails) {
          this.emails.set(email.id, email);
        }
        for (const mw of data.maintenanceWindows) {
          this.maintenanceWindows.set(mw.id, mw);
        }
        this.pointsEvents = data.pointsEvents;
        this.ticketIdCounter = data.ticketIdCounter;

        console.log('[DataStore] Loaded data from file');
      }
    } catch (err) {
      console.error('[DataStore] Failed to load data:', err);
    }
  }

  saveToFile(): void {
    try {
      const dir = path.dirname(DATA_FILE);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      const data: PersistedData = {
        tickets: this.getTickets(),
        emails: this.getEmails(),
        maintenanceWindows: this.getMaintenanceWindows(),
        pointsEvents: this.pointsEvents,
        ticketIdCounter: this.ticketIdCounter,
      };

      fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
      console.log('[DataStore] Data saved to file');
    } catch (err) {
      console.error('[DataStore] Failed to save data:', err);
    }
  }

  // ========== Wizard Sessions ==========

  getWizardSession(id: string): WizardSession | undefined {
    return this.wizardSessions.get(id);
  }

  setWizardSession(session: WizardSession): void {
    this.wizardSessions.set(session.id, session);
  }

  // ========== Tickets ==========

  getTicket(id: string): Ticket | undefined {
    return this.tickets.get(id);
  }

  getTickets(): Ticket[] {
    return Array.from(this.tickets.values());
  }

  setTicket(ticket: Ticket): void {
    this.tickets.set(ticket.id, ticket);
  }

  getNextTicketId(): number {
    return ++this.ticketIdCounter;
  }

  // ========== Emails ==========

  getEmail(id: string): EmailRecord | undefined {
    return this.emails.get(id);
  }

  getEmails(): EmailRecord[] {
    return Array.from(this.emails.values());
  }

  getEmailsByTicketId(ticketId: string): EmailRecord[] {
    return this.getEmails().filter((e) => e.ticketId === ticketId);
  }

  setEmail(email: EmailRecord): void {
    this.emails.set(email.id, email);
  }

  // ========== Maintenance Windows ==========

  getMaintenanceWindow(id: string): MaintenanceWindow | undefined {
    return this.maintenanceWindows.get(id);
  }

  getMaintenanceWindows(): MaintenanceWindow[] {
    return Array.from(this.maintenanceWindows.values());
  }

  setMaintenanceWindow(mw: MaintenanceWindow): void {
    this.maintenanceWindows.set(mw.id, mw);
  }

  // ========== Points ==========

  addPointsEvent(event: PointsEvent): void {
    this.pointsEvents.push(event);
  }

  getPointsEvents(): PointsEvent[] {
    return this.pointsEvents;
  }

  getTotalPoints(): number {
    return this.pointsEvents.reduce((sum, e) => sum + e.points, 0);
  }
}

// Singleton instance
export const dataStore = new DataStore();

// Note: Graceful shutdown (saveToFile) is handled in the server entry point (index.ts)
