import { dataStore } from '../store/dataStore.js';
import { sendSlaBreachEmail, sendReminderEmail, sendAutoCloseEmail } from './emailService.js';
import { awardPoints } from './pointsService.js';
import type { Ticket, TicketStatus } from '../models/types.js';

const SLA_BREACH_THRESHOLD_MS = 2 * 24 * 60 * 60 * 1000; // 2 days
const REMINDER_THRESHOLD_MS = 2 * 24 * 60 * 60 * 1000; // 2 days
const AUTO_CLOSE_THRESHOLD_MS = 3 * 24 * 60 * 60 * 1000; // 3 days

// Terminal statuses that should not be checked
const TERMINAL_STATUSES: TicketStatus[] = ['AUTO CLOSE', 'CANCELLED TICKET'];

export interface SlaCheckResult {
  ticketId: string;
  breached: boolean;
  daysInStatus: number;
  currentStatus: TicketStatus;
}

/**
 * Checks all active tickets for SLA breaches (> 2 days in same status).
 * Excludes "For User Acknowledgment" and terminal statuses.
 */
export function checkSlaBreaches(now: Date = new Date()): SlaCheckResult[] {
  const tickets = dataStore.getTickets().filter(
    (t) =>
      t.status !== 'For User Acknowledgment' &&
      !TERMINAL_STATUSES.includes(t.status)
  );

  const results: SlaCheckResult[] = [];

  for (const ticket of tickets) {
    const lastTransition = ticket.statusHistory[ticket.statusHistory.length - 1];
    if (!lastTransition) continue;

    const timeInStatus = now.getTime() - new Date(lastTransition.timestamp).getTime();
    const daysInStatus = timeInStatus / (24 * 60 * 60 * 1000);
    const breached = timeInStatus > SLA_BREACH_THRESHOLD_MS;

    if (breached) {
      // Calculate revised EWT (original EWT + additional delay)
      const revisedEwt = ticket.ewt + Math.ceil(daysInStatus * 24);

      sendSlaBreachEmail(ticket, revisedEwt);
      awardPoints(ticket.id, 'SLA_BREACH');

      // Apply ESCALATED tag if not already present
      if (!ticket.tags.includes('ESCALATED')) {
        ticket.tags.push('ESCALATED');
        dataStore.setTicket(ticket);
      }
    }

    results.push({
      ticketId: ticket.id,
      breached,
      daysInStatus,
      currentStatus: ticket.status,
    });
  }

  return results;
}

/**
 * Checks tickets in "For User Acknowledgment" status:
 * - Day 2: Send reminder email
 * - Day 3: Auto-close the ticket
 */
export function checkAutoCloseAndReminders(now: Date = new Date()): {
  reminders: string[];
  autoClosed: string[];
} {
  const tickets = dataStore.getTickets().filter(
    (t) => t.status === 'For User Acknowledgment'
  );

  const reminders: string[] = [];
  const autoClosed: string[] = [];

  for (const ticket of tickets) {
    const lastTransition = ticket.statusHistory[ticket.statusHistory.length - 1];
    if (!lastTransition) continue;

    const timeInStatus = now.getTime() - new Date(lastTransition.timestamp).getTime();

    if (timeInStatus > AUTO_CLOSE_THRESHOLD_MS) {
      // Auto-close: 3+ days
      ticket.status = 'AUTO CLOSE';
      ticket.statusHistory.push({
        from: 'For User Acknowledgment',
        to: 'AUTO CLOSE',
        timestamp: now.toISOString(),
      });
      ticket.updatedAt = now.toISOString();
      dataStore.setTicket(ticket);

      sendAutoCloseEmail(ticket);
      autoClosed.push(ticket.id);
    } else if (timeInStatus > REMINDER_THRESHOLD_MS) {
      // Reminder: 2+ days
      sendReminderEmail(ticket);
      reminders.push(ticket.id);
    }
  }

  return { reminders, autoClosed };
}

/**
 * Runs all SLA checks — intended to be called on a scheduled interval.
 */
export function runSlaChecks(now: Date = new Date()): {
  breaches: SlaCheckResult[];
  reminders: string[];
  autoClosed: string[];
} {
  const breaches = checkSlaBreaches(now);
  const { reminders, autoClosed } = checkAutoCloseAndReminders(now);
  return { breaches, reminders, autoClosed };
}
