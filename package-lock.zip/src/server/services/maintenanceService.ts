import type { MaintenanceWindow, SystemType } from '../models/types.js';

/**
 * Checks if a given system + dateTime falls within any active maintenance window.
 * Returns the matching MaintenanceWindow if found, or null otherwise.
 */
export function isWithinMaintenanceWindow(
  system: SystemType,
  dateTime: string,
  windows: MaintenanceWindow[]
): MaintenanceWindow | null {
  const checkTime = new Date(dateTime).getTime();

  if (isNaN(checkTime)) {
    return null;
  }

  const match = windows.find(
    (w) =>
      w.system === system &&
      checkTime >= new Date(w.startTime).getTime() &&
      checkTime <= new Date(w.endTime).getTime()
  );

  return match ?? null;
}
