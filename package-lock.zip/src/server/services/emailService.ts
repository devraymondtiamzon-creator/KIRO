import { v4 as uuidv4 } from 'uuid';
import { dataStore } from '../store/dataStore.js';
import type { EmailRecord, EmailType, Ticket, TicketStatus } from '../models/types.js';

/**
 * Core email send function — logs to console and stores as a record.
 * No actual email is sent (mock implementation).
 */
export function sendEmail(params: {
  ticketId: string;
  type: EmailType;
  to: string;
  subject: string;
  body: string;
}): EmailRecord {
  const record: EmailRecord = {
    id: uuidv4(),
    ticketId: params.ticketId,
    type: params.type,
    to: params.to,
    subject: params.subject,
    body: params.body,
    sentAt: new Date().toISOString(),
  };

  console.log(`[EMAIL] To: ${record.to} | Subject: ${record.subject}`);
  console.log(`[EMAIL] Body: ${record.body}`);
  console.log('---');

  dataStore.setEmail(record);
  return record;
}

/**
 * Sends an acknowledgment email when a ticket is created.
 * Includes the Estimated Waiting Time (EWT) based on the system type.
 */
export function sendAcknowledgmentEmail(ticket: Ticket): EmailRecord {
  return sendEmail({
    ticketId: ticket.id,
    type: 'ACKNOWLEDGMENT',
    to: ticket.userId,
    subject: `Ticket ${ticket.id} Created - ${ticket.systemAffected} Issue`,
    body: `Dear User,

Your support ticket ${ticket.id} has been created and is currently being evaluated.

Issue Summary:
- System: ${ticket.systemAffected}
- Error: ${ticket.errorDetails}
- Impact: ${ticket.impactLevel}
- Date Reported: ${ticket.dateTime}

Estimated Waiting Time (EWT): ${ticket.ewt} hour(s)

Our team will review your ticket shortly. You will receive updates as the ticket progresses.

Thank you for your patience.
IT Support Team`,
  });
}

/**
 * Sends a status update email when a ticket status changes.
 */
export function sendStatusUpdateEmail(ticket: Ticket, newStatus: TicketStatus): EmailRecord {
  return sendEmail({
    ticketId: ticket.id,
    type: 'STATUS_UPDATE',
    to: ticket.userId,
    subject: `Ticket ${ticket.id} Status Update - ${newStatus}`,
    body: `Dear User,

Your support ticket ${ticket.id} has been updated.

New Status: ${newStatus}

${getStatusMessage(newStatus)}

If you have any questions, please don't hesitate to reach out.

IT Support Team`,
  });
}

/**
 * Sends an SLA breach notification email with a revised EWT.
 */
export function sendSlaBreachEmail(ticket: Ticket, revisedEwt: number): EmailRecord {
  return sendEmail({
    ticketId: ticket.id,
    type: 'SLA_BREACH',
    to: ticket.userId,
    subject: `Ticket ${ticket.id} - Update on Resolution Timeline`,
    body: `Dear User,

We sincerely apologize for the delay in resolving your support ticket ${ticket.id}.

We understand how important this issue is to you, and we want to assure you that our team is actively working on it. Unfortunately, the resolution is taking longer than initially estimated.

Current Status: ${ticket.status}
Original EWT: ${ticket.ewt} hour(s)
Revised EWT: ${revisedEwt} hour(s)

We are committed to resolving this as quickly as possible and will keep you updated on any progress.

We deeply appreciate your patience and understanding.

IT Support Team`,
  });
}

/**
 * Sends a reminder email for tickets awaiting user acknowledgment.
 */
export function sendReminderEmail(ticket: Ticket): EmailRecord {
  return sendEmail({
    ticketId: ticket.id,
    type: 'REMINDER',
    to: ticket.userId,
    subject: `Reminder: Ticket ${ticket.id} - Awaiting Your Acknowledgment`,
    body: `Dear User,

This is a gentle reminder that your support ticket ${ticket.id} is awaiting your acknowledgment.

Please confirm that your issue has been resolved. If we do not hear from you within 24 hours, the ticket will be automatically closed.

How did we do?
Please rate your experience:
⭐⭐⭐⭐⭐ (5 Stars = Highest Satisfaction, 1 Star = Lowest Satisfaction)

IT Support Team`,
  });
}

/**
 * Sends a final notification when a ticket is auto-closed.
 */
export function sendAutoCloseEmail(ticket: Ticket): EmailRecord {
  return sendEmail({
    ticketId: ticket.id,
    type: 'AUTO_CLOSE',
    to: ticket.userId,
    subject: `Ticket ${ticket.id} - Automatically Closed`,
    body: `Dear User,

Your support ticket ${ticket.id} has been automatically closed due to inactivity.

If you believe your issue has not been fully resolved, please submit a new support request through the Self-Help Wizard.

Thank you.
IT Support Team`,
  });
}

// ========== Helpers ==========

function getStatusMessage(status: TicketStatus): string {
  const messages: Record<string, string> = {
    'Acknowledge For Evaluation':
      'Your ticket has been received and is being evaluated by our team.',
    'Resource Assignment':
      'A technician has been assigned to investigate your issue.',
    'Investigation Ongoing':
      'Our team is actively investigating the root cause of your issue.',
    'Resolution Ongoing':
      'We have identified the issue and are working on implementing a fix.',
    'For Documentation of RCA':
      'The issue has been resolved. We are documenting the root cause for future reference.',
    'For User Acknowledgment':
      'Your issue has been resolved! Please confirm by acknowledging this ticket.\n\nHow did we do?\nPlease rate your experience:\n⭐⭐⭐⭐⭐ (5 Stars = Highest Satisfaction, 1 Star = Lowest Satisfaction)',
    'CANCELLED TICKET':
      'This ticket has been cancelled.',
    'AUTO CLOSE':
      'This ticket has been automatically closed due to inactivity.',
    'FOR SCHEDULE OF VISIT':
      'An on-site visit has been scheduled to resolve your issue.',
    'WAITING DEVELOPER RESPONSE':
      'We are waiting for a response from our development team regarding your issue.',
  };

  return messages[status] ?? 'Your ticket status has been updated.';
}
