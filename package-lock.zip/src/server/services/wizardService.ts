import { v4 as uuidv4 } from 'uuid';
import { dataStore } from '../store/dataStore.js';
import { isWithinMaintenanceWindow } from './maintenanceService.js';
import type {
  WizardSession,
  WizardStepResult,
  SystemType,
  ImpactLevel,
  MaintenanceInfo,
} from '../models/types.js';
import { WizardStep, VALID_SYSTEMS, VALID_IMPACTS } from '../models/types.js';

// ========== Solution knowledge base ==========

const SOLUTIONS_DB: Record<SystemType, Record<string, string[]>> = {
  Network: {
    default: [
      'Try restarting your router/modem and wait 30 seconds before reconnecting.',
      'Run "ipconfig /release" then "ipconfig /renew" in Command Prompt to refresh your IP.',
    ],
  },
  Email: {
    default: [
      'Clear your email client cache and restart the application.',
      'Verify your credentials by logging into webmail directly at the portal URL.',
    ],
  },
  ERP: {
    default: [
      'Clear your browser cache and cookies, then log in again.',
      'Try using an incognito/private browsing window to access the ERP system.',
    ],
  },
  VPN: {
    default: [
      'Disconnect and reconnect to VPN. If that fails, restart the VPN client application.',
      'Check that your internet connection is stable before initiating the VPN connection.',
    ],
  },
  'Other Corporate Tools': {
    default: [
      'Restart the affected application and try the operation again.',
      'Ensure your application is updated to the latest version available.',
    ],
  },
};

// ========== Step Questions ==========

const STEP_QUESTIONS: Record<string, string> = {
  [WizardStep.ERROR_DETAILS]:
    'What is the specific error message or behavior you are experiencing?',
  [WizardStep.SYSTEM_AFFECTED]:
    'What system is this occurring on?',
  [WizardStep.DATE_TIME]:
    'When did this issue start occurring? (Please provide date and time)',
  [WizardStep.IMPACT_LEVEL]:
    'How many users are affected?',
  [WizardStep.RESOLUTION_CHECK]:
    'Did these steps resolve your issue? (Yes / No)',
};

// ========== Service Functions ==========

export function startSession(): WizardStepResult {
  const session: WizardSession = {
    id: uuidv4(),
    currentStep: WizardStep.ERROR_DETAILS,
    responses: {},
    solutions: [],
    resolved: null,
    createdAt: new Date().toISOString(),
  };

  dataStore.setWizardSession(session);

  return {
    sessionId: session.id,
    currentStep: session.currentStep,
    question: STEP_QUESTIONS[WizardStep.ERROR_DETAILS],
  };
}

export function getSession(sessionId: string): WizardSession | undefined {
  return dataStore.getWizardSession(sessionId);
}

export function advanceStep(sessionId: string, answer: string): WizardStepResult {
  const session = dataStore.getWizardSession(sessionId);
  if (!session) {
    throw new Error(`Session not found: ${sessionId}`);
  }

  switch (session.currentStep) {
    case WizardStep.ERROR_DETAILS:
      return handleErrorDetails(session, answer);

    case WizardStep.SYSTEM_AFFECTED:
      return handleSystemAffected(session, answer);

    case WizardStep.DATE_TIME:
      return handleDateTime(session, answer);

    case WizardStep.IMPACT_LEVEL:
      return handleImpactLevel(session, answer);

    case WizardStep.RESOLUTION_CHECK:
      return handleResolutionCheck(session, answer);

    default:
      throw new Error(`Cannot advance from step: ${session.currentStep}`);
  }
}

// ========== Step Handlers ==========

function handleErrorDetails(session: WizardSession, answer: string): WizardStepResult {
  session.responses.errorDetails = answer.trim();
  session.currentStep = WizardStep.SYSTEM_AFFECTED;
  dataStore.setWizardSession(session);

  return {
    sessionId: session.id,
    currentStep: session.currentStep,
    question: STEP_QUESTIONS[WizardStep.SYSTEM_AFFECTED],
    options: [...VALID_SYSTEMS],
  };
}

function handleSystemAffected(session: WizardSession, answer: string): WizardStepResult {
  session.responses.systemAffected = answer as SystemType;
  session.currentStep = WizardStep.DATE_TIME;
  dataStore.setWizardSession(session);

  return {
    sessionId: session.id,
    currentStep: session.currentStep,
    question: STEP_QUESTIONS[WizardStep.DATE_TIME],
  };
}

function handleDateTime(session: WizardSession, answer: string): WizardStepResult {
  session.responses.dateTime = answer;

  // Check maintenance window
  const system = session.responses.systemAffected!;
  const maintenanceMatch = isWithinMaintenanceWindow(
    system,
    answer,
    dataStore.getMaintenanceWindows()
  );

  if (maintenanceMatch) {
    session.currentStep = WizardStep.MAINTENANCE_HALT;
    dataStore.setWizardSession(session);

    const start = new Date(maintenanceMatch.startTime);
    const end = new Date(maintenanceMatch.endTime);
    const durationMs = end.getTime() - start.getTime();
    const durationHours = Math.round(durationMs / (1000 * 60 * 60));

    const maintenanceInfo: MaintenanceInfo = {
      system,
      downtimeDuration: `${durationHours} hour(s)`,
      scheduledUptime: maintenanceMatch.endTime,
      message: `The ${system} system is currently undergoing scheduled maintenance. The downtime is expected to last ${durationHours} hour(s). Please retry after ${maintenanceMatch.endTime}.`,
    };

    return {
      sessionId: session.id,
      currentStep: session.currentStep,
      maintenanceInfo,
    };
  }

  session.currentStep = WizardStep.IMPACT_LEVEL;
  dataStore.setWizardSession(session);

  return {
    sessionId: session.id,
    currentStep: session.currentStep,
    question: STEP_QUESTIONS[WizardStep.IMPACT_LEVEL],
    options: [...VALID_IMPACTS],
  };
}

function handleImpactLevel(session: WizardSession, answer: string): WizardStepResult {
  session.responses.impactLevel = answer as ImpactLevel;

  // Generate solutions
  const system = session.responses.systemAffected!;
  const solutions = getSolutions(system);
  session.solutions = solutions;
  session.currentStep = WizardStep.SOLUTIONS;
  dataStore.setWizardSession(session);

  // Immediately present solutions and ask resolution check
  session.currentStep = WizardStep.RESOLUTION_CHECK;
  dataStore.setWizardSession(session);

  return {
    sessionId: session.id,
    currentStep: session.currentStep,
    solutions,
    question: STEP_QUESTIONS[WizardStep.RESOLUTION_CHECK],
    options: ['Yes', 'No'],
  };
}

function handleResolutionCheck(session: WizardSession, answer: string): WizardStepResult {
  const resolved = answer.toLowerCase() === 'yes';
  session.resolved = resolved;
  session.currentStep = WizardStep.COMPLETED;
  dataStore.setWizardSession(session);

  return {
    sessionId: session.id,
    currentStep: session.currentStep,
  };
}

// ========== Helpers ==========

function getSolutions(system: SystemType): string[] {
  const systemSolutions = SOLUTIONS_DB[system];
  return systemSolutions?.default ?? [
    'Restart the affected application and try the operation again.',
    'Contact your system administrator for further assistance.',
  ];
}
