import type { Ticket, SmartTag } from '../models/types.js';

export interface TaggingContext {
  ticket: Ticket;
  recentTickets: Ticket[]; // tickets from last 7 days
}

/**
 * Computes smart tags for a ticket based on recurrence and escalation rules.
 *
 * [RECURRING]: Applied if an identical issue (same system + same error details)
 *              occurred within the past 7 days.
 * [ESCALATED]: Applied if impact level is Team or Entire Department.
 */
export function computeSmartTags(context: TaggingContext): SmartTag[] {
  const tags: SmartTag[] = [];

  // Recurring check: same system + same error details within 7 days
  const hasRecurrence = context.recentTickets.some(
    (t) =>
      t.id !== context.ticket.id &&
      t.systemAffected === context.ticket.systemAffected &&
      t.errorDetails.toLowerCase() === context.ticket.errorDetails.toLowerCase()
  );

  if (hasRecurrence) {
    tags.push('RECURRING');
  }

  // Escalation check: high impact level
  if (
    context.ticket.impactLevel === 'Team' ||
    context.ticket.impactLevel === 'Entire Department'
  ) {
    tags.push('ESCALATED');
  }

  return tags;
}
