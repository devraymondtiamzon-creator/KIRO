import { dataStore } from '../store/dataStore.js';
import { computeSmartTags } from './taggingService.js';
import { sendAcknowledgmentEmail, sendStatusUpdateEmail } from './emailService.js';
import { awardPoints } from './pointsService.js';
import type {
  Ticket,
  WizardSession,
  TicketStatus,
  StatusTransition,
  SmartTag,
} from '../models/types.js';
import { EWT_HOURS, VALID_TRANSITIONS } from '../models/types.js';

/**
 * Creates a ticket from a completed wizard session where the user
 * indicated the issue is not resolved.
 */
export function createTicket(session: WizardSession, userId: string = 'user@company.com'): Ticket {
  const year = new Date().getFullYear();
  const seq = dataStore.getNextTicketId();
  const ticketId = `INC-${year}-${seq}`;

  const systemAffected = session.responses.systemAffected!;
  const ewt = EWT_HOURS[systemAffected];

  const now = new Date().toISOString();

  const ticket: Ticket = {
    id: ticketId,
    errorDetails: session.responses.errorDetails!,
    systemAffected,
    dateTime: session.responses.dateTime!,
    impactLevel: session.responses.impactLevel!,
    status: 'Acknowledge For Evaluation',
    tags: [],
    ewt,
    statusHistory: [
      {
        from: 'Acknowledge For Evaluation',
        to: 'Acknowledge For Evaluation',
        timestamp: now,
      },
    ],
    csatRating: null,
    createdAt: now,
    updatedAt: now,
    resolvedAt: null,
    userId,
  };

  // Apply smart tags
  const recentTickets = getRecentTickets(7);
  const tags = computeSmartTags({ ticket, recentTickets });
  ticket.tags = tags;

  dataStore.setTicket(ticket);

  // Send acknowledgment email
  sendAcknowledgmentEmail(ticket);

  return ticket;
}

/**
 * Retrieves a ticket by ID.
 */
export function getTicket(id: string): Ticket | undefined {
  return dataStore.getTicket(id);
}

/**
 * Retrieves all tickets.
 */
export function getAllTickets(): Ticket[] {
  return dataStore.getTickets();
}

/**
 * Updates a ticket's status with validation against allowed transitions.
 * Returns the updated ticket or throws on invalid transition.
 */
export function updateTicketStatus(id: string, newStatus: TicketStatus): Ticket {
  const ticket = dataStore.getTicket(id);
  if (!ticket) {
    throw new Error(`Ticket not found: ${id}`);
  }

  const allowedTransitions = VALID_TRANSITIONS[ticket.status];
  if (!allowedTransitions.includes(newStatus)) {
    throw new Error(
      `Invalid status transition from "${ticket.status}" to "${newStatus}". Allowed: ${allowedTransitions.join(', ')}`
    );
  }

  const now = new Date().toISOString();
  const transition: StatusTransition = {
    from: ticket.status,
    to: newStatus,
    timestamp: now,
  };

  ticket.statusHistory.push(transition);
  ticket.status = newStatus;
  ticket.updatedAt = now;

  // Check if resolved (reaching For User Acknowledgment means issue is resolved)
  if (newStatus === 'For User Acknowledgment' && !ticket.resolvedAt) {
    ticket.resolvedAt = now;

    // Check if resolved within EWT
    const createdTime = new Date(ticket.createdAt).getTime();
    const resolvedTime = new Date(now).getTime();
    const ewtMs = ticket.ewt * 60 * 60 * 1000;
    if (resolvedTime - createdTime <= ewtMs) {
      awardPoints(ticket.id, 'RESOLVED_WITHIN_EWT');
    }
  }

  dataStore.setTicket(ticket);

  // Send status update email
  sendStatusUpdateEmail(ticket, newStatus);

  return ticket;
}

/**
 * Submits a CSAT rating for a ticket.
 */
export function submitCsatRating(id: string, rating: number): Ticket {
  const ticket = dataStore.getTicket(id);
  if (!ticket) {
    throw new Error(`Ticket not found: ${id}`);
  }

  if (rating < 1 || rating > 5 || !Number.isInteger(rating)) {
    throw new Error('CSAT rating must be an integer between 1 and 5');
  }

  ticket.csatRating = rating;
  ticket.updatedAt = new Date().toISOString();
  dataStore.setTicket(ticket);

  // Award points based on CSAT
  if (rating === 5) {
    awardPoints(ticket.id, 'CSAT_5_STAR');
  } else if (rating === 4) {
    awardPoints(ticket.id, 'CSAT_4_STAR');
  } else if (rating <= 2) {
    awardPoints(ticket.id, 'CSAT_LOW');
  }

  return ticket;
}

/**
 * Gets tickets created within the last N days.
 */
export function getRecentTickets(days: number): Ticket[] {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);
  const cutoffTime = cutoff.getTime();

  return dataStore.getTickets().filter(
    (t) => new Date(t.createdAt).getTime() >= cutoffTime
  );
}
