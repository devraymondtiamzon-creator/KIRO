import { v4 as uuidv4 } from 'uuid';
import { dataStore } from '../store/dataStore.js';
import type { PointsEvent, PointsEventType } from '../models/types.js';
import { POINTS_MAP } from '../models/types.js';

/**
 * Awards (or deducts) performance points for a given event.
 */
export function awardPoints(ticketId: string | null, eventType: PointsEventType): PointsEvent {
  const points = POINTS_MAP[eventType];

  const event: PointsEvent = {
    id: uuidv4(),
    ticketId,
    eventType,
    points,
    timestamp: new Date().toISOString(),
  };

  dataStore.addPointsEvent(event);

  console.log(
    `[POINTS] ${eventType}: ${points > 0 ? '+' : ''}${points} points${ticketId ? ` (Ticket: ${ticketId})` : ''}`
  );

  return event;
}

/**
 * Calculates the appropriate points event type and value for a CSAT rating.
 * Returns null for a rating of 3 (neutral — no points awarded).
 */
export function calculateCsatPoints(
  rating: number
): { eventType: PointsEventType; points: number } | null {
  if (rating === 5) return { eventType: 'CSAT_5_STAR', points: 10 };
  if (rating === 4) return { eventType: 'CSAT_4_STAR', points: 5 };
  if (rating <= 2) return { eventType: 'CSAT_LOW', points: -5 };
  return null; // rating 3 gives no points
}

/**
 * Gets the total accumulated performance points.
 */
export function getTotalPoints(): number {
  return dataStore.getTotalPoints();
}

/**
 * Gets all points events for display/reporting.
 */
export function getPointsEvents(): PointsEvent[] {
  return dataStore.getPointsEvents();
}
