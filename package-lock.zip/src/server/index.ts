import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import wizardRoutes from './routes/wizardRoutes.js';
import ticketRoutes from './routes/ticketRoutes.js';
import emailRoutes from './routes/emailRoutes.js';
import pointsRoutes from './routes/pointsRoutes.js';
import adminRoutes from './routes/adminRoutes.js';
import { runSlaChecks } from './services/slaService.js';
import { dataStore } from './store/dataStore.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

// ========== Middleware ==========

app.use(cors());
app.use(express.json());

// ========== Routes ==========

app.use('/api/wizard', wizardRoutes);
app.use('/api/tickets', ticketRoutes);
app.use('/api/emails', emailRoutes);
app.use('/api/points', pointsRoutes);
app.use('/api/admin', adminRoutes);
// Also mount admin routes at root for /api/maintenance-windows convenience
app.use('/api', adminRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ========== Static Frontend Serving ==========

const clientDistPath = path.resolve(__dirname, '../../dist/client');
app.use(express.static(clientDistPath));

// SPA fallback: serve index.html for any non-API route
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(clientDistPath, 'index.html'));
  }
});

// ========== Error Handling ==========

app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('[ERROR]', err.message || err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal Server Error',
    code: err.code || 'INTERNAL_ERROR',
  });
});

// ========== Background SLA Check (every hour) ==========

const SLA_CHECK_INTERVAL_MS = 60 * 60 * 1000; // 1 hour

const slaInterval = setInterval(() => {
  console.log('[SLA] Running scheduled SLA checks...');
  const results = runSlaChecks();
  if (results.breaches.filter((b) => b.breached).length > 0) {
    console.log(`[SLA] Detected ${results.breaches.filter((b) => b.breached).length} breach(es)`);
  }
  if (results.autoClosed.length > 0) {
    console.log(`[SLA] Auto-closed ${results.autoClosed.length} ticket(s)`);
  }
  if (results.reminders.length > 0) {
    console.log(`[SLA] Sent ${results.reminders.length} reminder(s)`);
  }
}, SLA_CHECK_INTERVAL_MS);

// ========== Graceful Shutdown ==========

function shutdown() {
  console.log('\n[Server] Shutting down gracefully...');
  clearInterval(slaInterval);
  dataStore.saveToFile();
  process.exit(0);
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

// ========== Start Server ==========

app.listen(PORT, () => {
  console.log(`[Server] IT Self-Help & Smart Ticketing system running on http://localhost:${PORT}`);
  console.log(`[Server] API endpoints available at http://localhost:${PORT}/api`);
});

export default app;
